// CRM Surface — admin: customer database, subscriptions, branch performance.

function CRMSurface({ tweaks, navigate }) {
  const [tab, setTab] = React.useState('overview');
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '220px 1fr', minHeight: '100%', background: CX.bgMuted }}>
      <CRMSidebar tab={tab} setTab={setTab} navigate={navigate} />
      <div style={{ overflowY: 'auto' }}>
        <CRMTopBar tab={tab} />
        <div style={{ padding: '24px 32px 64px' }}>
          {tab === 'overview' && <CRMOverview />}
          {tab === 'customers' && <CRMCustomers />}
          {tab === 'subscriptions' && <CRMSubscriptions />}
          {tab === 'branches' && <CRMBranches />}
          {tab === 'campaigns' && <CRMCampaigns />}
        </div>
      </div>
    </div>
  );
}

function CRMSidebar({ tab, setTab, navigate }) {
  const items = [
    { id: 'overview', label: 'Overview', icon: 'grid' },
    { id: 'customers', label: 'Customers', icon: 'users' },
    { id: 'subscriptions', label: 'Subscriptions', icon: 'crown' },
    { id: 'branches', label: 'Branches', icon: 'pin' },
    { id: 'campaigns', label: 'Campaigns', icon: 'mail' },
  ];
  return (
    <div style={{ background: CX.ink, color: '#fff', padding: '20px 14px', display: 'flex', flexDirection: 'column' }}>
      <div style={{ padding: '4px 8px 18px', borderBottom: '1px solid #27272A', marginBottom: 14, display: 'flex', alignItems: 'center', gap: 10 }}>
        <Wordmark size={20} mono />
        <span style={{ fontSize: 10, fontWeight: 800, color: CX.secondary, letterSpacing: 2 }}>CRM</span>
      </div>
      {items.map(it => {
        const a = tab === it.id;
        return (
          <button key={it.id} onClick={() => setTab(it.id)} style={{
            display: 'flex', alignItems: 'center', gap: 12, padding: '10px 12px', marginBottom: 2,
            background: a ? '#1F1F2A' : 'transparent', color: a ? '#fff' : '#9CA3AF',
            border: 'none', borderRadius: 8, fontFamily: 'inherit', fontSize: 13, fontWeight: 600,
            cursor: 'pointer', textAlign: 'left', borderLeft: '3px solid ' + (a ? CX.secondary : 'transparent'),
          }}>
            <Icon name={it.icon} size={16} />{it.label}
          </button>
        );
      })}
      <div style={{ marginTop: 'auto', borderTop: '1px solid #27272A', paddingTop: 12, display: 'flex', alignItems: 'center', gap: 10 }}>
        <Avatar name="Admin" size={32} color={CX.secondary} />
        <div style={{ fontSize: 12 }}>
          <div style={{ fontWeight: 700 }}>Admin · Owner</div>
          <button onClick={() => navigate('landing')} style={{ background: 'none', border: 'none', color: '#9CA3AF', fontSize: 11, cursor: 'pointer', padding: 0, fontFamily: 'inherit' }}>Sign out</button>
        </div>
      </div>
    </div>
  );
}

function CRMTopBar({ tab }) {
  return (
    <div style={{ background: '#fff', borderBottom: '1px solid ' + CX.border, padding: '16px 32px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <div style={{ fontSize: 22, fontWeight: 900, color: CX.ink, letterSpacing: -0.5, textTransform: 'capitalize' }}>{tab}</div>
      <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
        <div style={{ position: 'relative' }}>
          <Icon name="search" size={14} color={CX.fgMuted} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)' }} />
          <input placeholder="Search customers, plates, IDs…" style={{ padding: '8px 12px 8px 34px', border: '1px solid ' + CX.border, borderRadius: 8, fontSize: 13, fontFamily: 'inherit', width: 280, outline: 'none' }} />
        </div>
        <SoftButton variant="outline" icon="bell" />
        <BrutalistButton color={CX.primary} size="sm" icon="plus">New customer</BrutalistButton>
      </div>
    </div>
  );
}

function CRMOverview() {
  const stats = [
    { label: 'Total customers', val: 4872, delta: '+128 this week', color: CX.primary },
    { label: 'Active subscribers', val: 612, delta: '+24 this week', color: CX.secondary },
    { label: 'Revenue (April)', val: 'BND 28.4k', delta: '↑ 12% MoM', color: CX.green },
    { label: 'Avg wait time', val: '11m', delta: '↓ 2m vs March', color: CX.fg },
  ];
  return (
    <div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 20 }}>
        {stats.map((s, i) => (
          <Card key={i} padding={20}>
            <div style={{ fontSize: 11, fontWeight: 700, color: CX.fgMuted, textTransform: 'uppercase', letterSpacing: 0.5 }}>{s.label}</div>
            <div style={{ fontSize: 32, fontWeight: 900, color: s.color, letterSpacing: -1, marginTop: 8 }}>{s.val}</div>
            <div style={{ fontSize: 12, color: CX.green, marginTop: 4, fontWeight: 600 }}>{s.delta}</div>
          </Card>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: 16, marginBottom: 20 }}>
        {/* Sparkline / chart */}
        <Card padding={24}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 18 }}>
            <div>
              <div style={{ fontSize: 11, fontWeight: 700, color: CX.fgMuted, textTransform: 'uppercase', letterSpacing: 0.5 }}>Daily washes · last 30 days</div>
              <div style={{ fontSize: 32, fontWeight: 900, color: CX.ink, letterSpacing: -1, marginTop: 6 }}>8,420 washes</div>
            </div>
            <div style={{ display: 'flex', gap: 4 }}>
              {['7D', '30D', '90D'].map((p, i) => <button key={p} style={{ padding: '6px 12px', fontSize: 12, fontWeight: 700, fontFamily: 'inherit', background: i === 1 ? CX.ink : 'transparent', color: i === 1 ? '#fff' : CX.fgMuted, border: '1px solid ' + (i === 1 ? CX.ink : CX.border), borderRadius: 6, cursor: 'pointer' }}>{p}</button>)}
            </div>
          </div>
          <Chart />
        </Card>
        {/* Top branches */}
        <Card padding={24}>
          <div style={{ fontSize: 11, fontWeight: 700, color: CX.fgMuted, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 16 }}>Branch leaderboard · today</div>
          {BRANCHES.slice().sort((a, b) => b.todayCars - a.todayCars).map((b, i) => (
            <div key={b.id} style={{ display: 'grid', gridTemplateColumns: '24px 1fr 1fr 60px', alignItems: 'center', gap: 10, padding: '10px 0', borderTop: i ? '1px solid ' + CX.border : 'none' }}>
              <div style={{ fontSize: 13, fontWeight: 800, color: i === 0 ? CX.secondary : CX.fgMuted }}>#{i + 1}</div>
              <div style={{ fontSize: 14, fontWeight: 700 }}>{b.name}</div>
              <div style={{ background: CX.bgMuted, height: 6, borderRadius: 999, overflow: 'hidden' }}>
                <div style={{ height: '100%', width: (b.todayCars / 87 * 100) + '%', background: CX.primary, borderRadius: 999 }} />
              </div>
              <div style={{ fontSize: 14, fontWeight: 800, textAlign: 'right' }}>{b.todayCars}</div>
            </div>
          ))}
        </Card>
      </div>

      {/* Recent activity feed */}
      <Card padding={24}>
        <div style={{ fontSize: 11, fontWeight: 700, color: CX.fgMuted, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 16 }}>Live activity</div>
        <div style={{ display: 'grid', gap: 8 }}>
          {[
            { icon: 'droplet', tone: CX.primary, text: 'Hjh Suriana A. — Full Package · Tungku Link', time: '2 min ago', val: 'BND 12' },
            { icon: 'crown', tone: CX.secondary, text: 'Yusof bin Hassan upgraded to Corporate Fleet', time: '12 min ago', val: '+BND 280/mo' },
            { icon: 'user', tone: CX.green, text: 'New customer: Sarah Lee · onboarded via QR scan at Salar', time: '24 min ago', val: '' },
            { icon: 'messageCircle', tone: CX.blue, text: 'Daniel Wong left a 5-star review on Google', time: '1 hr ago', val: '★★★★★' },
            { icon: 'trash', tone: CX.red, text: 'Mohd Iqbal R. cancelled subscription', time: '2 hr ago', val: '−BND 60/mo' },
          ].map((a, i) => (
            <div key={i} style={{ display: 'grid', gridTemplateColumns: '36px 1fr auto auto', alignItems: 'center', gap: 12, padding: '10px 0', borderTop: i ? '1px solid ' + CX.border : 'none' }}>
              <div style={{ width: 36, height: 36, borderRadius: '50%', background: a.tone + '22', color: a.tone, display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon name={a.icon} size={16} /></div>
              <div style={{ fontSize: 13 }}>{a.text}</div>
              <div style={{ fontSize: 12, fontWeight: 700, color: CX.fgMuted }}>{a.val}</div>
              <div style={{ fontSize: 12, color: CX.fgSubtle }}>{a.time}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

function Chart() {
  // 30 fake data points
  const data = React.useMemo(() => Array.from({ length: 30 }, (_, i) => 180 + Math.sin(i / 3) * 40 + Math.random() * 60 + i * 3), []);
  const max = Math.max(...data); const min = Math.min(...data);
  const W = 700, H = 180;
  const points = data.map((v, i) => `${(i / (data.length - 1)) * W},${H - ((v - min) / (max - min)) * H}`).join(' ');
  return (
    <svg viewBox={`0 0 ${W} ${H + 20}`} style={{ width: '100%', height: 200 }}>
      <defs>
        <linearGradient id="cxgrad" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor={CX.primary} stopOpacity="0.4" />
          <stop offset="100%" stopColor={CX.primary} stopOpacity="0" />
        </linearGradient>
      </defs>
      <polyline points={`0,${H} ${points} ${W},${H}`} fill="url(#cxgrad)" />
      <polyline points={points} fill="none" stroke={CX.primary} strokeWidth="2.5" strokeLinejoin="round" strokeLinecap="round" />
      {data.map((v, i) => i % 5 === 0 && (
        <circle key={i} cx={(i / (data.length - 1)) * W} cy={H - ((v - min) / (max - min)) * H} r="3" fill={CX.primary} />
      ))}
    </svg>
  );
}

function CRMCustomers() {
  const [sel, setSel] = React.useState(null);
  return (
    <div style={{ display: 'grid', gridTemplateColumns: sel ? '1.4fr 1fr' : '1fr', gap: 16 }}>
      <Card padding={0}>
        <div style={{ display: 'grid', gridTemplateColumns: '1.6fr 1fr 1fr 80px 100px 100px 30px', padding: '14px 20px', background: CX.bgMuted, fontSize: 11, fontWeight: 800, color: CX.fgMuted, textTransform: 'uppercase', letterSpacing: 0.5 }}>
          <div>Customer</div><div>Phone</div><div>Tier</div><div style={{ textAlign: 'right' }}>Washes</div><div style={{ textAlign: 'right' }}>LTV</div><div>Last seen</div><div></div>
        </div>
        {CRM_CUSTOMERS.map((c, i) => (
          <button key={c.id} onClick={() => setSel(c)} style={{
            display: 'grid', gridTemplateColumns: '1.6fr 1fr 1fr 80px 100px 100px 30px', padding: '14px 20px', alignItems: 'center', borderTop: i ? '1px solid ' + CX.border : 'none',
            background: sel?.id === c.id ? CX.primary10 : '#fff', textAlign: 'left', cursor: 'pointer', border: 'none', fontFamily: 'inherit', width: '100%',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <Avatar name={c.name} size={32} />
              <div>
                <div style={{ fontSize: 14, fontWeight: 700, color: CX.fg }}>{c.name}</div>
                <div style={{ fontSize: 11, color: CX.fgMuted }}>{c.vehicles} vehicles · {c.branch}</div>
              </div>
            </div>
            <div style={{ fontSize: 13, color: CX.fg, fontFamily: 'monospace' }}>{c.phone}</div>
            <div><Badge color={c.tier === 'Unlimited' ? 'purple' : c.tier === 'Family' ? 'orange' : c.tier === 'Corporate' ? 'dark' : 'gray'}>{c.tier}</Badge></div>
            <div style={{ fontSize: 14, fontWeight: 800, textAlign: 'right' }}>{c.washes}</div>
            <div style={{ fontSize: 14, fontWeight: 800, color: CX.green, textAlign: 'right' }}>BND {c.ltv}</div>
            <div style={{ fontSize: 12, color: CX.fgMuted }}>{c.lastSeen}</div>
            <Icon name="chevronRight" size={14} color={CX.fgMuted} />
          </button>
        ))}
      </Card>
      {sel && <CustomerDetail c={sel} onClose={() => setSel(null)} />}
    </div>
  );
}

function CustomerDetail({ c, onClose }) {
  return (
    <Card padding={24}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20 }}>
        <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
          <Avatar name={c.name} size={56} />
          <div>
            <div style={{ fontSize: 20, fontWeight: 900, color: CX.ink }}>{c.name}</div>
            <div style={{ fontSize: 13, color: CX.fgMuted, fontFamily: 'monospace' }}>{c.phone}</div>
          </div>
        </div>
        <button onClick={onClose} style={{ background: 'transparent', border: 'none', cursor: 'pointer' }}><Icon name="x" /></button>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, marginBottom: 20 }}>
        {[['Tier', c.tier], ['Washes', c.washes], ['LTV', 'BND ' + c.ltv]].map(([k, v], i) => (
          <div key={i} style={{ background: CX.bgMuted, borderRadius: 10, padding: 14 }}>
            <div style={{ fontSize: 10, fontWeight: 700, color: CX.fgMuted, textTransform: 'uppercase', letterSpacing: 0.5 }}>{k}</div>
            <div style={{ fontSize: 18, fontWeight: 800, color: CX.fg }}>{v}</div>
          </div>
        ))}
      </div>
      <div style={{ fontSize: 11, fontWeight: 800, color: CX.fgMuted, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 10 }}>Recent washes</div>
      <div style={{ display: 'grid', gap: 8, marginBottom: 18 }}>
        {RECENT_WASHES.slice(0, 4).map(w => (
          <div key={w.id} style={{ display: 'grid', gridTemplateColumns: '1fr auto', alignItems: 'center', padding: '8px 12px', background: CX.bgMuted, borderRadius: 8, fontSize: 12 }}>
            <div>{w.date.split(' ')[0]} · {w.branch} · {w.package}</div>
            <div style={{ fontWeight: 800 }}>BND {w.amount}</div>
          </div>
        ))}
      </div>
      <div style={{ display: 'flex', gap: 8 }}>
        <SoftButton variant="primary" icon="messageCircle" size="sm">WhatsApp</SoftButton>
        <SoftButton variant="outline" icon="gift" size="sm">Send voucher</SoftButton>
        <SoftButton variant="outline" icon="edit" size="sm">Edit</SoftButton>
      </div>
    </Card>
  );
}

function CRMSubscriptions() {
  const tiers = [
    { name: 'Unlimited Xpress', price: 60, count: 412, churn: 2.4, color: CX.primary },
    { name: 'Multi-Car Family', price: 150, count: 168, churn: 1.1, color: CX.secondary },
    { name: 'Corporate Fleet', price: 280, count: 32, churn: 0, color: CX.ink },
  ];
  return (
    <div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 20 }}>
        {tiers.map((t, i) => (
          <Card key={i} padding={24}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
              <Badge color={i === 0 ? 'purple' : i === 1 ? 'orange' : 'dark'}>{t.name}</Badge>
              <Icon name="crown" color={t.color} />
            </div>
            <div style={{ fontSize: 40, fontWeight: 900, color: t.color, letterSpacing: -1, lineHeight: 1 }}>{t.count}</div>
            <div style={{ fontSize: 12, color: CX.fgMuted, marginBottom: 14 }}>active members · BND {t.price}/mo</div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, padding: '8px 0', borderTop: '1px solid ' + CX.border }}>
              <span style={{ color: CX.fgMuted }}>MRR</span>
              <span style={{ fontWeight: 800 }}>BND {(t.count * t.price).toLocaleString()}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, padding: '8px 0', borderTop: '1px solid ' + CX.border }}>
              <span style={{ color: CX.fgMuted }}>Churn (30d)</span>
              <span style={{ fontWeight: 800, color: t.churn > 2 ? CX.red : CX.green }}>{t.churn}%</span>
            </div>
          </Card>
        ))}
      </div>
      <Card padding={24}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <div style={{ fontSize: 16, fontWeight: 800 }}>Renewals this week</div>
          <SoftButton variant="ghost" size="sm" iconRight="arrowRight">All renewals</SoftButton>
        </div>
        {CRM_CUSTOMERS.filter(c => c.tier !== 'Pay-as-you-go').slice(0, 4).map((c, i) => (
          <div key={c.id} style={{ display: 'grid', gridTemplateColumns: '36px 1.4fr 1fr 100px auto', alignItems: 'center', gap: 12, padding: '12px 0', borderTop: i ? '1px solid ' + CX.border : 'none' }}>
            <Avatar name={c.name} size={32} />
            <div style={{ fontSize: 13, fontWeight: 700 }}>{c.name}</div>
            <Badge color={c.tier === 'Unlimited' ? 'purple' : c.tier === 'Family' ? 'orange' : 'dark'} size="sm">{c.tier}</Badge>
            <div style={{ fontSize: 12, color: CX.fgMuted }}>Renews May {2 + i}</div>
            <SoftButton variant="outline" size="sm">Remind</SoftButton>
          </div>
        ))}
      </Card>
    </div>
  );
}

function CRMBranches() {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 16 }}>
      {BRANCHES.map(b => (
        <Card key={b.id} padding={24}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
            <div>
              {b.flag && <Badge color="orange" style={{ marginBottom: 6 }}>★ {b.flag}</Badge>}
              <div style={{ fontSize: 22, fontWeight: 900, color: CX.ink }}>{b.name}</div>
              <div style={{ fontSize: 12, color: CX.fgMuted }}>{b.address}</div>
            </div>
            <Badge color={b.status === 'busy' ? 'red' : 'green'}>{b.status}</Badge>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10, marginBottom: 14 }}>
            {[['Today', b.todayCars], ['Queue', b.queue + ' cars'], ['Wait', b.eta + 'm']].map(([k, v], i) => (
              <div key={i} style={{ background: CX.bgMuted, borderRadius: 8, padding: 12 }}>
                <div style={{ fontSize: 10, fontWeight: 700, color: CX.fgMuted, textTransform: 'uppercase', letterSpacing: 0.5 }}>{k}</div>
                <div style={{ fontSize: 18, fontWeight: 800 }}>{v}</div>
              </div>
            ))}
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <SoftButton variant="outline" size="sm" icon="settings">Configure</SoftButton>
            <SoftButton variant="outline" size="sm" icon="users">Crew</SoftButton>
            <SoftButton variant="outline" size="sm" icon="barchart">Reports</SoftButton>
          </div>
        </Card>
      ))}
    </div>
  );
}

function CRMCampaigns() {
  const items = [
    { name: 'Rainy day re-wash', status: 'Live', channel: 'WhatsApp + SMS', sent: 1240, open: 78, ctr: 22, color: CX.primary },
    { name: 'Subscription early access', status: 'Scheduled', channel: 'Email', sent: 0, open: 0, ctr: 0, color: CX.secondary },
    { name: 'Hari Raya weekend promo', status: 'Draft', channel: 'WhatsApp', sent: 0, open: 0, ctr: 0, color: CX.fgMuted },
  ];
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: 16 }}>
        <BrutalistButton color={CX.primary} icon="plus">New campaign</BrutalistButton>
      </div>
      <Card padding={0}>
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 100px 1.2fr 80px 80px 80px 50px', padding: '14px 20px', background: CX.bgMuted, fontSize: 11, fontWeight: 800, color: CX.fgMuted, textTransform: 'uppercase', letterSpacing: 0.5 }}>
          <div>Campaign</div><div>Status</div><div>Channel</div><div style={{ textAlign: 'right' }}>Sent</div><div style={{ textAlign: 'right' }}>Open</div><div style={{ textAlign: 'right' }}>CTR</div><div></div>
        </div>
        {items.map((c, i) => (
          <div key={i} style={{ display: 'grid', gridTemplateColumns: '2fr 100px 1.2fr 80px 80px 80px 50px', padding: '16px 20px', alignItems: 'center', borderTop: i ? '1px solid ' + CX.border : 'none' }}>
            <div>
              <div style={{ fontSize: 14, fontWeight: 700, color: CX.fg }}>{c.name}</div>
              <div style={{ fontSize: 11, color: CX.fgMuted }}>Created Apr {25 + i}</div>
            </div>
            <Badge color={c.status === 'Live' ? 'green' : c.status === 'Scheduled' ? 'orange' : 'gray'}>{c.status}</Badge>
            <div style={{ fontSize: 13, color: CX.fg }}>{c.channel}</div>
            <div style={{ fontSize: 13, fontWeight: 700, textAlign: 'right' }}>{c.sent || '—'}</div>
            <div style={{ fontSize: 13, fontWeight: 700, textAlign: 'right' }}>{c.open ? c.open + '%' : '—'}</div>
            <div style={{ fontSize: 13, fontWeight: 700, textAlign: 'right', color: c.ctr ? CX.green : CX.fgMuted }}>{c.ctr ? c.ctr + '%' : '—'}</div>
            <button style={{ background: 'transparent', border: 'none', cursor: 'pointer' }}><Icon name="moreHorizontal" /></button>
          </div>
        ))}
      </Card>
    </div>
  );
}

window.CRMSurface = CRMSurface;
