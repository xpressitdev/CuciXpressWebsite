// Shared utilities, mock data, and small components used across surfaces.

const CX = {
  primary: '#7C5CE7',
  primaryDark: '#6345D0',
  primaryLight: '#A78BFA',
  primary10: 'rgba(124,92,231,0.10)',
  primary20: 'rgba(124,92,231,0.20)',
  secondary: '#FF9500',
  secondaryDark: '#E68600',
  secondary10: 'rgba(255,149,0,0.10)',
  green: '#22C55E',
  blue: '#3B82F6',
  red: '#EF4444',
  yellow: '#EAB308',
  pink: '#EC4899',
  ink: '#0B0B12',
  fg: '#111827',
  fgMuted: '#6B7280',
  fgSubtle: '#9CA3AF',
  border: '#E5E7EB',
  borderStrong: '#D1D5DB',
  bg: '#FFFFFF',
  bgMuted: '#F9FAFB',
  bgSoft: '#F3F4F6',
  shadowSm: '0 1px 2px rgba(0,0,0,0.05)',
  shadow: '0 1px 3px rgba(0,0,0,0.1), 0 1px 2px rgba(0,0,0,0.06)',
  shadowMd: '0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -1px rgba(0,0,0,0.06)',
  shadowLg: '0 10px 15px -3px rgba(0,0,0,0.08), 0 4px 6px -2px rgba(0,0,0,0.04)',
  shadowXl: '0 20px 25px -5px rgba(0,0,0,0.1), 0 10px 10px -5px rgba(0,0,0,0.04)',
  brutalist: '4px 4px 0 0 rgba(0,0,0,0.92)',
  brutalistHover: '6px 6px 0 0 rgba(0,0,0,0.92)',
};

window.CX = CX;

// ---------- Wordmark ----------
function Wordmark({ size = 24, mono = false }) {
  return (
    <span style={{ fontSize: size, fontWeight: 800, letterSpacing: -0.5, display: 'inline-flex' }}>
      <span style={{ color: mono ? 'currentColor' : CX.primary }}>Cuci</span>
      <span style={{ color: mono ? 'currentColor' : CX.secondary }}>Xpress</span>
    </span>
  );
}
window.Wordmark = Wordmark;

// ---------- Lucide icon shortcut ----------
function Icon({ name, size = 18, color = 'currentColor', strokeWidth = 2, style }) {
  // Tiny inline subset — Lucide-style strokes for the icons we need.
  const paths = {
    car: <><path d="M14 16H9m10 0h3v-3.15a1 1 0 0 0-.84-.99L16 11l-2.7-3.6a1 1 0 0 0-.8-.4H5.24a2 2 0 0 0-1.8 1.1l-.8 1.63A6 6 0 0 0 2 12.42V16h2"/><circle cx="6.5" cy="16.5" r="2.5"/><circle cx="16.5" cy="16.5" r="2.5"/></>,
    sparkle: <><path d="M12 3v18M3 12h18M5.5 5.5l13 13M18.5 5.5l-13 13"/></>,
    shield: <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>,
    clock: <><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></>,
    phone: <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>,
    pin: <><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></>,
    star: <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>,
    check: <polyline points="20 6 9 17 4 12"/>,
    x: <><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></>,
    chevronDown: <polyline points="6 9 12 15 18 9"/>,
    chevronRight: <polyline points="9 18 15 12 9 6"/>,
    chevronLeft: <polyline points="15 18 9 12 15 6"/>,
    menu: <><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="18" x2="21" y2="18"/></>,
    user: <><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></>,
    users: <><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></>,
    plus: <><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></>,
    arrowRight: <><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></>,
    arrowUp: <><line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/></>,
    arrowDown: <><line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/></>,
    search: <><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></>,
    bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></>,
    home: <><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></>,
    grid: <><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></>,
    settings: <><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></>,
    creditCard: <><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></>,
    cash: <><rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2"/><path d="M6 12h.01M18 12h.01"/></>,
    qr: <><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><line x1="14" y1="14" x2="14" y2="17"/><line x1="17" y1="14" x2="20" y2="14"/><line x1="20" y1="17" x2="20" y2="20"/><line x1="14" y1="20" x2="17" y2="20"/></>,
    droplet: <path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"/>,
    crown: <><path d="M2 19h20l-2-9-5 4-3-7-3 7-5-4-2 9z"/></>,
    trending: <><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></>,
    activity: <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>,
    calendar: <><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></>,
    download: <><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></>,
    edit: <><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></>,
    trash: <><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></>,
    gift: <><polyline points="20 12 20 22 4 22 4 12"/><rect x="2" y="7" width="20" height="5"/><line x1="12" y1="22" x2="12" y2="7"/><path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"/><path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"/></>,
    receipt: <><path d="M4 2v20l3-2 3 2 3-2 3 2 3-2 3 2V2l-3 2-3-2-3 2-3-2-3 2-3-2z"/><line x1="8" y1="8" x2="16" y2="8"/><line x1="8" y1="12" x2="16" y2="12"/><line x1="8" y1="16" x2="12" y2="16"/></>,
    play: <polygon points="5 3 19 12 5 21 5 3"/>,
    pause: <><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></>,
    logout: <><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></>,
    filter: <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>,
    moreHorizontal: <><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/></>,
    zap: <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>,
    eye: <><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></>,
    mail: <><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></>,
    messageCircle: <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>,
    refresh: <><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></>,
    barchart: <><line x1="12" y1="20" x2="12" y2="10"/><line x1="18" y1="20" x2="18" y2="4"/><line x1="6" y1="20" x2="6" y2="16"/></>,
    sun: <><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></>,
    moon: <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>,
    award: <><circle cx="12" cy="8" r="7"/><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/></>,
    target: <><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/></>,
    smile: <><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></>,
    truck: <><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></>,
    layers: <><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></>,
    wifi: <><path d="M5 12.55a11 11 0 0 1 14.08 0"/><path d="M1.42 9a16 16 0 0 1 21.16 0"/><path d="M8.53 16.11a6 6 0 0 1 6.95 0"/><line x1="12" y1="20" x2="12.01" y2="20"/></>,
  };
  const p = paths[name] || paths.check;
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" style={style} aria-hidden="true">
      {p}
    </svg>
  );
}
window.Icon = Icon;

// ---------- Brutalist button ----------
function BrutalistButton({ children, onClick, color = CX.primary, fg = '#fff', size = 'md', icon, fullWidth, style }) {
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  const sizes = {
    sm: { padding: '8px 16px', fontSize: 13 },
    md: { padding: '12px 22px', fontSize: 15 },
    lg: { padding: '16px 28px', fontSize: 16 },
  };
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => { setHover(false); setActive(false); }}
      onMouseDown={() => setActive(true)}
      onMouseUp={() => setActive(false)}
      style={{
        background: color,
        color: fg,
        border: '2px solid #000',
        borderRadius: 8,
        fontWeight: 800,
        fontFamily: 'inherit',
        cursor: 'pointer',
        boxShadow: active ? '2px 2px 0 0 rgba(0,0,0,0.92)' : (hover ? CX.brutalistHover : CX.brutalist),
        transform: active ? 'translate(2px, 2px)' : (hover ? 'translate(-2px, -2px)' : 'translate(0,0)'),
        transition: 'all 0.12s ease',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        width: fullWidth ? '100%' : 'auto',
        ...sizes[size],
        ...style,
      }}
    >
      {children}
      {icon && <Icon name={icon} size={16} />}
    </button>
  );
}
window.BrutalistButton = BrutalistButton;

// ---------- Soft button ----------
function SoftButton({ children, onClick, variant = 'primary', size = 'md', icon, iconRight, style, disabled }) {
  const [hover, setHover] = React.useState(false);
  const variants = {
    primary: { bg: CX.primary, fg: '#fff', hoverBg: CX.primaryDark },
    secondary: { bg: CX.secondary, fg: '#fff', hoverBg: CX.secondaryDark },
    ghost: { bg: 'transparent', fg: CX.fg, hoverBg: CX.bgSoft },
    outline: { bg: '#fff', fg: CX.fg, hoverBg: CX.bgSoft, border: '1px solid ' + CX.border },
    danger: { bg: '#fff', fg: CX.red, hoverBg: '#FEF2F2', border: '1px solid #FECACA' },
    dark: { bg: CX.ink, fg: '#fff', hoverBg: '#1F2937' },
  };
  const sizes = {
    sm: { padding: '6px 12px', fontSize: 12, borderRadius: 6 },
    md: { padding: '9px 16px', fontSize: 14, borderRadius: 8 },
    lg: { padding: '12px 22px', fontSize: 15, borderRadius: 10 },
  };
  const v = variants[variant];
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        background: hover && !disabled ? v.hoverBg : v.bg,
        color: v.fg,
        border: v.border || 'none',
        fontWeight: 600,
        fontFamily: 'inherit',
        cursor: disabled ? 'not-allowed' : 'pointer',
        opacity: disabled ? 0.5 : 1,
        transition: 'all 0.15s ease',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 6,
        ...sizes[size],
        ...style,
      }}
    >
      {icon && <Icon name={icon} size={14} />}
      {children}
      {iconRight && <Icon name={iconRight} size={14} />}
    </button>
  );
}
window.SoftButton = SoftButton;

// ---------- Badge ----------
function Badge({ children, color = 'gray', size = 'md', style }) {
  const palettes = {
    gray:    { bg: CX.bgSoft, fg: CX.fg },
    purple:  { bg: CX.primary10, fg: CX.primary },
    orange:  { bg: CX.secondary10, fg: CX.secondaryDark },
    green:   { bg: '#DCFCE7', fg: '#15803D' },
    red:     { bg: '#FEE2E2', fg: '#B91C1C' },
    blue:    { bg: '#DBEAFE', fg: '#1D4ED8' },
    yellow:  { bg: '#FEF3C7', fg: '#92400E' },
    dark:    { bg: CX.ink, fg: '#fff' },
  };
  const sizes = {
    sm: { padding: '2px 8px', fontSize: 10, borderRadius: 999 },
    md: { padding: '4px 10px', fontSize: 11, borderRadius: 999 },
    lg: { padding: '6px 14px', fontSize: 13, borderRadius: 999 },
  };
  const p = palettes[color];
  return (
    <span style={{ background: p.bg, color: p.fg, fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: 4, ...sizes[size], ...style }}>
      {children}
    </span>
  );
}
window.Badge = Badge;

// ---------- Card ----------
function Card({ children, style, padding = 24, hover = false, ...rest }) {
  const [h, setH] = React.useState(false);
  return (
    <div
      onMouseEnter={() => hover && setH(true)}
      onMouseLeave={() => hover && setH(false)}
      style={{
        background: '#fff',
        border: '1px solid ' + CX.border,
        borderRadius: 16,
        padding,
        boxShadow: h ? CX.shadowXl : CX.shadowLg,
        transition: 'all 0.2s ease',
        ...style,
      }}
      {...rest}
    >
      {children}
    </div>
  );
}
window.Card = Card;

// ---------- StatCounter (animates a number on mount) ----------
function StatCounter({ to, duration = 1500, prefix = '', suffix = '', decimals = 0 }) {
  const [v, setV] = React.useState(0);
  React.useEffect(() => {
    let start = null; let raf;
    const step = (ts) => {
      if (!start) start = ts;
      const t = Math.min(1, (ts - start) / duration);
      const eased = 1 - Math.pow(1 - t, 3);
      setV(eased * to);
      if (t < 1) raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [to, duration]);
  return <span>{prefix}{v.toLocaleString(undefined, { maximumFractionDigits: decimals, minimumFractionDigits: decimals })}{suffix}</span>;
}
window.StatCounter = StatCounter;

// ---------- Avatar ----------
function Avatar({ name, size = 36, color }) {
  const initials = (name || '?').split(' ').map(s => s[0]).slice(0, 2).join('').toUpperCase();
  const palette = ['#7C5CE7', '#FF9500', '#22C55E', '#3B82F6', '#EC4899', '#EAB308'];
  const c = color || palette[name ? name.charCodeAt(0) % palette.length : 0];
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%', background: c, color: '#fff',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontWeight: 700, fontSize: size * 0.38, flexShrink: 0,
    }}>{initials}</div>
  );
}
window.Avatar = Avatar;

// ---------- Mock data ----------
const BRANCHES = [
  { id: 'tungku', name: 'Tungku Link', flag: 'Flagship', queue: 4, eta: 14, washing: 2, todayCars: 87, capacity: 6, lat: 4.97, lng: 114.91, address: 'Spg 88, Jalan Tungku Link', status: 'open' },
  { id: 'salar', name: 'Salar', queue: 1, eta: 5, washing: 1, todayCars: 52, capacity: 4, lat: 4.93, lng: 114.97, address: 'Kg Salar, Mukim Pengkalan Batu', status: 'open' },
  { id: 'bengkurong', name: 'Bengkurong', queue: 2, eta: 9, washing: 2, todayCars: 64, capacity: 4, lat: 4.92, lng: 114.86, address: 'Jalan Bengkurong, Mukim Sengkurong', status: 'open' },
  { id: 'tutong', name: 'Tutong', queue: 0, eta: 0, washing: 0, todayCars: 31, capacity: 4, lat: 4.79, lng: 114.65, address: 'Jalan Pekan Tutong', status: 'open' },
  { id: 'lambak', name: 'Lambak', queue: 6, eta: 22, washing: 2, todayCars: 41, capacity: 4, lat: 4.94, lng: 114.96, address: 'Lambak Kanan, BSB', status: 'busy' },
];
window.BRANCHES = BRANCHES;

const PACKAGES = [
  { id: 'basic', name: 'Basic Wash', price: 8, duration: 8, color: CX.primary, features: ['Exterior foam wash', 'High-pressure rinse', 'Basic dry'] },
  { id: 'full', name: 'Full Package', price: 12, duration: 12, color: CX.secondary, features: ['Everything in Basic', 'Spray wax', 'Wheel cleaning', 'Tire shine'], popular: true },
  { id: 'premium', name: 'Premium Detail', price: 25, duration: 25, color: CX.ink, features: ['Everything in Full', 'Hand-finish dry', 'Interior vacuum', 'Dashboard wipe'] },
];
window.PACKAGES = PACKAGES;

const RECENT_WASHES = [
  { id: 'W-2401', date: '2026-04-29 14:32', branch: 'Tungku Link', package: 'Full Package', plate: 'KB 2891', amount: 12, payment: 'BIBD QuickPay' },
  { id: 'W-2398', date: '2026-04-22 09:18', branch: 'Tungku Link', package: 'Full Package', plate: 'KB 2891', amount: 12, payment: 'Subscription' },
  { id: 'W-2390', date: '2026-04-15 17:05', branch: 'Salar', package: 'Basic Wash', plate: 'KB 2891', amount: 8, payment: 'Cash' },
  { id: 'W-2375', date: '2026-04-08 11:44', branch: 'Bengkurong', package: 'Full Package', plate: 'KA 0142', amount: 12, payment: 'Card' },
  { id: 'W-2368', date: '2026-04-01 15:50', branch: 'Tungku Link', package: 'Premium Detail', plate: 'KB 2891', amount: 25, payment: 'Subscription' },
  { id: 'W-2354', date: '2026-03-24 10:22', branch: 'Tutong', package: 'Basic Wash', plate: 'KA 0142', amount: 8, payment: 'BIBD QuickPay' },
];
window.RECENT_WASHES = RECENT_WASHES;

const VEHICLES = [
  { plate: 'KB 2891', model: 'Toyota Hilux', color: 'Pearl White', washes: 18, lastWash: '2 days ago' },
  { plate: 'KA 0142', model: 'Honda Civic', color: 'Modern Steel', washes: 7, lastWash: '1 week ago' },
];
window.VEHICLES = VEHICLES;

const CRM_CUSTOMERS = [
  { id: 1, name: 'Hjh Suriana Abdullah', phone: '+673 871 2245', tier: 'Unlimited', washes: 47, ltv: 480, lastSeen: 'Today', branch: 'Tungku Link', vehicles: 2 },
  { id: 2, name: 'Daniel Wong', phone: '+673 720 1199', tier: 'Pay-as-you-go', washes: 12, ltv: 144, lastSeen: '2 days ago', branch: 'Salar', vehicles: 1 },
  { id: 3, name: 'Zarina Hj Mahmud', phone: '+673 882 4407', tier: 'Family', washes: 31, ltv: 612, lastSeen: 'Yesterday', branch: 'Tungku Link', vehicles: 3 },
  { id: 4, name: 'Ahmad Khairul', phone: '+673 711 8821', tier: 'Unlimited', washes: 22, ltv: 240, lastSeen: '4 days ago', branch: 'Bengkurong', vehicles: 1 },
  { id: 5, name: 'Lim Mei Ling', phone: '+673 730 5544', tier: 'Pay-as-you-go', washes: 8, ltv: 96, lastSeen: '1 week ago', branch: 'Tutong', vehicles: 2 },
  { id: 6, name: 'Yusof bin Hassan', phone: '+673 891 2200', tier: 'Corporate', washes: 158, ltv: 2280, lastSeen: 'Today', branch: 'Tungku Link', vehicles: 8 },
  { id: 7, name: 'Catherine Tan', phone: '+673 712 6633', tier: 'Family', washes: 19, ltv: 280, lastSeen: '3 days ago', branch: 'Lambak', vehicles: 2 },
  { id: 8, name: 'Mohd Iqbal Rahman', phone: '+673 873 9911', tier: 'Pay-as-you-go', washes: 4, ltv: 48, lastSeen: '2 weeks ago', branch: 'Salar', vehicles: 1 },
];
window.CRM_CUSTOMERS = CRM_CUSTOMERS;

const QUEUE_NOW = [
  { id: 'A24', plate: 'KB 2891', package: 'Full', stage: 'washing', progress: 0.62, customer: 'Hjh Suriana' },
  { id: 'A25', plate: 'BFA 7712', package: 'Basic', stage: 'washing', progress: 0.30, customer: 'Daniel W.' },
  { id: 'A26', plate: 'KA 0142', package: 'Full', stage: 'queued', progress: 0, customer: 'Zarina M.' },
  { id: 'A27', plate: 'KC 5520', package: 'Basic', stage: 'queued', progress: 0, customer: 'Walk-in' },
  { id: 'A28', plate: 'KB 9981', package: 'Premium', stage: 'queued', progress: 0, customer: 'Yusof H.' },
  { id: 'A29', plate: 'BAB 3344', package: 'Full', stage: 'queued', progress: 0, customer: 'Catherine T.' },
];
window.QUEUE_NOW = QUEUE_NOW;
