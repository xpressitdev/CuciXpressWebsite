// Landing page — refreshed marketing surface with live queue widget integrated.

function LandingPage({ tweaks, navigate }) {
  const accent = tweaks.accent === 'orange' ? CX.secondary : CX.primary;
  const accentDark = tweaks.accent === 'orange' ? CX.secondaryDark : CX.primaryDark;

  return (
    <div style={{ background: '#fff', minHeight: '100%' }}>
      <LandingNav navigate={navigate} />
      <Hero accent={accent} navigate={navigate} />
      <LiveStrip />
      <Stats />
      <PackagesSection />
      <BranchesSection />
      <SubscriptionTease accent={accent} />
      <Testimonials />
      <FooterBlock />
    </div>
  );
}

// --- Top nav ---
function LandingNav({ navigate }) {
  const [scrolled, setScrolled] = React.useState(false);
  React.useEffect(() => {
    const h = () => setScrolled(window.scrollY > 40);
    const root = document.querySelector('[data-scroll-root]');
    if (root) { root.addEventListener('scroll', () => setScrolled(root.scrollTop > 40)); }
    window.addEventListener('scroll', h);
    return () => window.removeEventListener('scroll', h);
  }, []);
  const items = [['Pricing', 'pricing'], ['Locations', 'branches'], ['Live Queue', 'queue'], ['Subscriptions', 'subs']];
  return (
    <nav style={{
      position: 'sticky', top: 0, zIndex: 30,
      background: 'rgba(255,255,255,0.92)', backdropFilter: 'blur(12px)',
      borderBottom: scrolled ? '1px solid ' + CX.border : '1px solid transparent',
      transition: 'all 0.2s ease',
    }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '0 32px', height: 68, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <Wordmark size={26} />
        <div style={{ display: 'flex', gap: 28, alignItems: 'center' }}>
          {items.map(([label, id]) => (
            <button key={id} style={{ background: 'none', border: 'none', fontFamily: 'inherit', fontSize: 14, fontWeight: 600, color: CX.fg, cursor: 'pointer' }}>{label}</button>
          ))}
          <SoftButton variant="ghost" onClick={() => navigate('dashboard')}>Sign in</SoftButton>
          <BrutalistButton size="sm" color={CX.primary} onClick={() => navigate('queue')}>Pay & Queue →</BrutalistButton>
        </div>
      </div>
    </nav>
  );
}

// --- Hero ---
function Hero({ accent, navigate }) {
  return (
    <section style={{ position: 'relative', overflow: 'hidden', padding: '88px 32px 100px' }}>
      {/* offset grid */}
      <div style={{
        position: 'absolute', inset: 0,
        backgroundImage: `linear-gradient(${CX.border} 1px, transparent 1px), linear-gradient(90deg, ${CX.border} 1px, transparent 1px)`,
        backgroundSize: '64px 64px',
        maskImage: 'radial-gradient(ellipse at center, #000 0%, transparent 70%)',
        WebkitMaskImage: 'radial-gradient(ellipse at center, #000 0%, transparent 70%)',
        opacity: 0.5,
      }} />
      <div style={{ position: 'absolute', top: -60, right: -60, width: 480, height: 480, borderRadius: '50%', background: `radial-gradient(circle, ${CX.secondary10}, transparent 70%)` }} />
      <div style={{ position: 'absolute', bottom: -100, left: -80, width: 520, height: 520, borderRadius: '50%', background: `radial-gradient(circle, ${CX.primary10}, transparent 70%)` }} />

      <div style={{ position: 'relative', maxWidth: 1280, margin: '0 auto', display: 'grid', gridTemplateColumns: '1.1fr 1fr', gap: 64, alignItems: 'center' }}>
        <div>
          <Badge color="purple" size="lg" style={{ marginBottom: 24 }}>
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: CX.green, boxShadow: '0 0 0 4px rgba(34,197,94,0.2)' }} />
            5 branches open · 14 cars in queue
          </Badge>
          <h1 style={{ fontSize: 76, fontWeight: 900, lineHeight: 0.96, letterSpacing: -2.5, color: CX.ink, marginBottom: 28 }}>
            Drive in.<br />
            Drive out.<br />
            <span style={{ background: `linear-gradient(90deg, ${CX.primary}, ${CX.secondary})`, WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>Sparkling clean.</span>
          </h1>
          <p style={{ fontSize: 19, color: CX.fgMuted, lineHeight: 1.55, maxWidth: 520, marginBottom: 36 }}>
            Brunei&rsquo;s drive-thru car wash — five branches, eight-minute washes, zero appointments needed. We&rsquo;ve cleaned <strong style={{ color: CX.fg }}>120,000+ cars</strong> and counting.
          </p>
          <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap' }}>
            <BrutalistButton color={CX.primary} size="lg" onClick={() => navigate('queue')}>Pay &amp; Queue Now →</BrutalistButton>
            <BrutalistButton color="#fff" fg={CX.ink} size="lg" onClick={() => navigate('queue')}>See live queue</BrutalistButton>
          </div>

          <div style={{ marginTop: 48, display: 'flex', gap: 32, alignItems: 'center' }}>
            <div style={{ display: 'flex' }}>
              {[CX.primary, CX.secondary, CX.green, '#3B82F6'].map((c, i) => (
                <div key={i} style={{ width: 36, height: 36, borderRadius: '50%', background: c, border: '2px solid #fff', marginLeft: i === 0 ? 0 : -10, color: '#fff', fontSize: 12, fontWeight: 700, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>{['HS','DW','ZM','+1k'][i]}</div>
              ))}
            </div>
            <div>
              <div style={{ display: 'flex', gap: 2, marginBottom: 4 }}>
                {[1,2,3,4,5].map(i => <Icon key={i} name="star" size={14} color={CX.yellow} style={{ fill: CX.yellow }} />)}
                <span style={{ fontSize: 13, fontWeight: 700, color: CX.fg, marginLeft: 6 }}>4.8</span>
              </div>
              <div style={{ fontSize: 12, color: CX.fgMuted }}>1,200+ Google Reviews</div>
            </div>
          </div>
        </div>

        {/* Right: live queue card preview */}
        <LiveQueueCard />
      </div>
    </section>
  );
}

function LiveQueueCard() {
  const [tick, setTick] = React.useState(0);
  React.useEffect(() => {
    const id = setInterval(() => setTick(t => t + 1), 2000);
    return () => clearInterval(id);
  }, []);
  return (
    <div style={{ position: 'relative' }}>
      <div style={{
        background: '#fff', border: '2px solid #000', borderRadius: 20,
        boxShadow: '8px 8px 0 0 rgba(0,0,0,0.92)', padding: 24,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ width: 8, height: 8, borderRadius: '50%', background: CX.green, boxShadow: '0 0 0 4px rgba(34,197,94,0.2)', animation: 'cxpulse 1.6s infinite' }} />
            <span style={{ fontSize: 12, fontWeight: 700, color: CX.fg, letterSpacing: 1, textTransform: 'uppercase' }}>Live · {new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}</span>
          </div>
          <Badge color="dark">Today · {120 + tick} washed</Badge>
        </div>
        <h3 style={{ fontSize: 18, fontWeight: 800, color: CX.fg, marginBottom: 14 }}>Queue across all branches</h3>
        <div style={{ display: 'grid', gap: 10 }}>
          {BRANCHES.map(b => {
            const wait = b.eta;
            const pct = Math.min(100, (b.queue / b.capacity) * 100);
            const tone = wait === 0 ? CX.green : wait < 10 ? CX.green : wait < 20 ? CX.secondary : CX.red;
            return (
              <div key={b.id} style={{ display: 'grid', gridTemplateColumns: '120px 1fr 60px', gap: 12, alignItems: 'center' }}>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 700, color: CX.fg }}>{b.name}</div>
                  {b.flag && <div style={{ fontSize: 10, fontWeight: 700, color: CX.secondary, textTransform: 'uppercase', letterSpacing: 0.5 }}>{b.flag}</div>}
                </div>
                <div style={{ position: 'relative', height: 8, background: CX.bgSoft, borderRadius: 999, overflow: 'hidden' }}>
                  <div style={{ position: 'absolute', inset: 0, width: pct + '%', background: tone, borderRadius: 999, transition: 'width 0.6s ease' }} />
                </div>
                <div style={{ fontSize: 13, fontWeight: 800, color: tone, textAlign: 'right' }}>{wait === 0 ? 'Open' : '~' + wait + 'm'}</div>
              </div>
            );
          })}
        </div>
        <div style={{ marginTop: 18, padding: '12px 14px', background: CX.bgMuted, borderRadius: 10, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ fontSize: 13, color: CX.fgMuted }}>Shortest wait now</div>
          <div style={{ fontSize: 14, fontWeight: 800, color: CX.primary }}>Tutong · drive in</div>
        </div>
      </div>
      <style>{`
        @keyframes cxpulse { 0%,100% { box-shadow: 0 0 0 0 rgba(34,197,94,0.45); } 70% { box-shadow: 0 0 0 8px rgba(34,197,94,0); } }
      `}</style>
    </div>
  );
}

// --- "Live strip" — running ticker of recent washes ---
function LiveStrip() {
  const items = [
    'KB 2891 · Tungku Link · Full Package · 12 BND',
    'BFA 7712 · Salar · Basic · 8 BND',
    'KA 0142 · Bengkurong · Full Package · 12 BND',
    'KC 5520 · Tungku Link · Premium Detail · 25 BND',
    'KB 9981 · Lambak · Full Package · 12 BND',
    'BAB 3344 · Tutong · Basic · 8 BND',
  ];
  return (
    <div style={{ background: CX.ink, color: '#fff', padding: '14px 0', overflow: 'hidden', borderTop: '2px solid #000', borderBottom: '2px solid #000' }}>
      <div style={{ display: 'flex', gap: 48, animation: 'cxmarquee 40s linear infinite', whiteSpace: 'nowrap', fontSize: 13, fontWeight: 600 }}>
        {[...items, ...items, ...items].map((t, i) => (
          <span key={i} style={{ display: 'inline-flex', alignItems: 'center', gap: 12 }}>
            <span style={{ color: CX.green }}>●</span>
            <span style={{ color: '#9CA3AF' }}>JUST WASHED</span>
            <span>{t}</span>
            <span style={{ color: '#374151' }}>·</span>
          </span>
        ))}
      </div>
      <style>{`@keyframes cxmarquee { from { transform: translateX(0); } to { transform: translateX(-33.33%); } }`}</style>
    </div>
  );
}

// --- Stats ---
function Stats() {
  return (
    <section style={{ padding: '96px 32px', background: CX.bgMuted }}>
      <div style={{ maxWidth: 1280, margin: '0 auto' }}>
        <div style={{ textAlign: 'center', marginBottom: 56 }}>
          <Badge color="orange" size="md" style={{ marginBottom: 14 }}>By the numbers</Badge>
          <h2 style={{ fontSize: 48, fontWeight: 900, color: CX.ink, letterSpacing: -1, lineHeight: 1.05 }}>Built for Brunei.<br /><span style={{ color: CX.primary }}>Washed for speed.</span></h2>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 20 }}>
          {[
            { n: 120000, label: 'Cars cleaned', suffix: '+' },
            { n: 5, label: 'Branches across Brunei' },
            { n: 22, label: 'Trained crew members' },
            { n: 4.8, label: 'Google rating', decimals: 1 },
          ].map((s, i) => (
            <div key={i} style={{ background: '#fff', borderRadius: 16, border: '1px solid ' + CX.border, padding: 32 }}>
              <div style={{ fontSize: 56, fontWeight: 900, color: CX.primary, letterSpacing: -2, lineHeight: 1 }}>
                <StatCounter to={s.n} suffix={s.suffix || ''} decimals={s.decimals || 0} />
              </div>
              <div style={{ fontSize: 14, fontWeight: 600, color: CX.fgMuted, marginTop: 10 }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// --- Packages ---
function PackagesSection() {
  return (
    <section id="pricing" style={{ padding: '96px 32px', background: '#fff' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 48 }}>
          <div>
            <Badge color="purple" size="md" style={{ marginBottom: 14 }}>Pricing</Badge>
            <h2 style={{ fontSize: 48, fontWeight: 900, color: CX.ink, letterSpacing: -1, marginBottom: 12 }}>Same price, every car.</h2>
            <p style={{ fontSize: 17, color: CX.fgMuted, maxWidth: 540 }}>No surprises. Sedan or 4x4, our prices are flat. Pay once, queue from your phone.</p>
          </div>
          <SoftButton variant="ghost" iconRight="arrowRight">Compare all</SoftButton>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20 }}>
          {PACKAGES.map((p, i) => (
            <div key={p.id} style={{
              position: 'relative',
              background: p.popular
                ? `linear-gradient(135deg, ${CX.primary} 0%, #B47CF7 45%, ${CX.secondary} 100%)`
                : '#fff',
              color: p.popular ? '#fff' : CX.fg,
              border: '2px solid #000',
              borderRadius: 20,
              padding: 32,
              boxShadow: p.popular
                ? '8px 8px 0 0 rgba(0,0,0,0.92), 0 0 60px rgba(255,149,0,0.45), 0 0 100px rgba(124,92,231,0.35)'
                : CX.brutalist,
              overflow: 'hidden',
            }}>
              {p.popular && (
                <>
                  {/* Sparkle shine overlay */}
                  <div style={{
                    position: 'absolute', inset: 0,
                    background: 'radial-gradient(circle at 25% 15%, rgba(255,255,255,0.55), transparent 38%), radial-gradient(circle at 80% 90%, rgba(255,255,255,0.25), transparent 45%)',
                    pointerEvents: 'none',
                  }} />
                  {/* Diagonal shimmer streak */}
                  <div style={{
                    position: 'absolute', top: -40, left: -40, right: -40, bottom: -40,
                    background: 'linear-gradient(115deg, transparent 38%, rgba(255,255,255,0.55) 48%, rgba(255,255,255,0.0) 58%)',
                    animation: 'cxshimmer 3.6s ease-in-out infinite',
                    pointerEvents: 'none',
                    mixBlendMode: 'overlay',
                  }} />
                  {/* Twinkles */}
                  {[
                    { t: 14, l: 60, s: 14, d: 0 },
                    { t: 110, l: 36, s: 10, d: 0.6 },
                    { t: 70, l: 240, s: 8, d: 1.2 },
                    { t: 220, l: 280, s: 12, d: 1.8 },
                    { t: 280, l: 80, s: 9, d: 0.3 },
                  ].map((s, si) => (
                    <svg key={si} width={s.s} height={s.s} viewBox="0 0 24 24" style={{
                      position: 'absolute', top: s.t, left: s.l, pointerEvents: 'none',
                      animation: `cxtwinkle 2.4s ease-in-out ${s.d}s infinite`,
                    }}>
                      <path d="M12 0 L13.5 10.5 L24 12 L13.5 13.5 L12 24 L10.5 13.5 L0 12 L10.5 10.5 Z" fill="#fff" />
                    </svg>
                  ))}
                </>
              )}
              {p.popular && (
                <div style={{ position: 'absolute', top: -12, right: 24, background: CX.secondary, color: '#000', fontSize: 11, fontWeight: 800, padding: '4px 12px', borderRadius: 999, border: '2px solid #000', textTransform: 'uppercase', letterSpacing: 0.5, zIndex: 2 }}>★ Most picked</div>
              )}
              <div style={{ position: 'relative', zIndex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 800, color: p.popular ? '#FFE89E' : p.color, textTransform: 'uppercase', letterSpacing: 1.5, marginBottom: 8, textShadow: p.popular ? '0 1px 8px rgba(0,0,0,0.25)' : 'none' }}>{p.name}</div>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 6, marginBottom: 4 }}>
                  <span style={{ fontSize: 64, fontWeight: 900, letterSpacing: -2.5, lineHeight: 1, textShadow: p.popular ? '0 4px 20px rgba(0,0,0,0.18)' : 'none' }}>{p.price}</span>
                  <span style={{ fontSize: 16, fontWeight: 700, color: p.popular ? 'rgba(255,255,255,0.85)' : CX.fgMuted }}>BND</span>
                </div>
                <div style={{ fontSize: 13, fontWeight: 600, color: p.popular ? 'rgba(255,255,255,0.85)' : CX.fgMuted, marginBottom: 24, display: 'flex', alignItems: 'center', gap: 6 }}>
                  <Icon name="clock" size={14} /> ~{p.duration} min in &amp; out
                </div>
                <ul style={{ listStyle: 'none', padding: 0, margin: '0 0 28px', display: 'grid', gap: 10 }}>
                  {p.features.map((f, fi) => (
                    <li key={fi} style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 14, fontWeight: p.popular ? 600 : 400 }}>
                      <span style={{ width: 18, height: 18, borderRadius: '50%', background: p.popular ? '#fff' : '#DCFCE7', color: p.popular ? CX.primary : '#15803D', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', boxShadow: p.popular ? '0 2px 8px rgba(0,0,0,0.15)' : 'none' }}>
                        <Icon name="check" size={12} strokeWidth={3} />
                      </span>
                      {f}
                    </li>
                  ))}
                </ul>
                <BrutalistButton fullWidth color={p.popular ? '#fff' : CX.primary} fg={p.popular ? CX.primary : '#fff'}>
                  {p.popular ? '✦ Pick this one' : 'Choose ' + p.name}
                </BrutalistButton>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// --- Branches ---
function BranchesSection() {
  return (
    <section id="branches" style={{ padding: '96px 32px', background: CX.bgMuted }}>
      <div style={{ maxWidth: 1280, margin: '0 auto' }}>
        <div style={{ marginBottom: 48 }}>
          <Badge color="orange" size="md" style={{ marginBottom: 14 }}>5 locations</Badge>
          <h2 style={{ fontSize: 48, fontWeight: 900, color: CX.ink, letterSpacing: -1 }}>Find us near you.</h2>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
          {BRANCHES.map(b => (
            <div key={b.id} style={{ background: '#fff', border: '1px solid ' + CX.border, borderRadius: 16, padding: 24, position: 'relative' }}>
              {b.flag && (
                <div style={{ position: 'absolute', top: 16, right: 16, fontSize: 10, fontWeight: 800, color: CX.secondary, textTransform: 'uppercase', letterSpacing: 1 }}>★ {b.flag}</div>
              )}
              <div style={{ fontSize: 22, fontWeight: 800, color: CX.ink, marginBottom: 4 }}>{b.name}</div>
              <div style={{ fontSize: 13, color: CX.fgMuted, marginBottom: 18 }}>{b.address}</div>
              <div style={{ display: 'flex', gap: 16, marginBottom: 16 }}>
                <div>
                  <div style={{ fontSize: 11, fontWeight: 700, color: CX.fgSubtle, textTransform: 'uppercase', letterSpacing: 0.5 }}>Wait</div>
                  <div style={{ fontSize: 20, fontWeight: 800, color: b.eta < 10 ? CX.green : b.eta < 20 ? CX.secondary : CX.red }}>{b.eta === 0 ? 'Open' : '~' + b.eta + 'm'}</div>
                </div>
                <div>
                  <div style={{ fontSize: 11, fontWeight: 700, color: CX.fgSubtle, textTransform: 'uppercase', letterSpacing: 0.5 }}>In queue</div>
                  <div style={{ fontSize: 20, fontWeight: 800, color: CX.fg }}>{b.queue} cars</div>
                </div>
                <div>
                  <div style={{ fontSize: 11, fontWeight: 700, color: CX.fgSubtle, textTransform: 'uppercase', letterSpacing: 0.5 }}>Today</div>
                  <div style={{ fontSize: 20, fontWeight: 800, color: CX.fg }}>{b.todayCars}</div>
                </div>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <SoftButton variant="dark" size="sm" icon="pin">Directions</SoftButton>
                <SoftButton variant="outline" size="sm" icon="phone">Call</SoftButton>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// --- Subscriptions tease ---
function SubscriptionTease({ accent }) {
  return (
    <section id="subs" style={{ padding: '96px 32px', background: '#fff' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 64, alignItems: 'center' }}>
        <div>
          <Badge color="purple" size="md" style={{ marginBottom: 14 }}>Coming soon</Badge>
          <h2 style={{ fontSize: 48, fontWeight: 900, color: CX.ink, letterSpacing: -1, lineHeight: 1.05, marginBottom: 20 }}>Wash as much as you drive.</h2>
          <p style={{ fontSize: 17, color: CX.fgMuted, lineHeight: 1.6, marginBottom: 28 }}>One flat monthly fee. Drive in any time, any branch. Rain re-wash on us.</p>
          <div style={{ display: 'grid', gap: 12, marginBottom: 28 }}>
            {[['Unlimited Xpress', 'BND 60 / mo', 'Single car · all branches'], ['Multi-Car Family', 'BND 150 / mo', 'Up to 3 cars'], ['Corporate Fleet', 'Custom', '5+ vehicles, monthly billing']].map(([n, p, d], i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 18px', borderRadius: 12, border: '1px solid ' + CX.border, background: i === 0 ? CX.primary10 : '#fff' }}>
                <div>
                  <div style={{ fontSize: 15, fontWeight: 800, color: CX.fg }}>{n}</div>
                  <div style={{ fontSize: 12, color: CX.fgMuted }}>{d}</div>
                </div>
                <div style={{ fontSize: 16, fontWeight: 800, color: CX.primary }}>{p}</div>
              </div>
            ))}
          </div>
          <BrutalistButton color={CX.secondary} fg="#000">Join the waitlist</BrutalistButton>
        </div>
        <div style={{
          position: 'relative', aspectRatio: '4/5',
          background: `linear-gradient(135deg, ${CX.primary} 0%, #B47CF7 45%, ${CX.secondary} 100%)`,
          borderRadius: 24, padding: 32, border: '2px solid #000',
          boxShadow: '12px 12px 0 0 rgba(0,0,0,0.92), 0 0 80px rgba(255,149,0,0.4), 0 0 120px rgba(124,92,231,0.3)',
          color: '#fff', overflow: 'hidden', display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
        }}>
          {/* Sparkle shine overlay */}
          <div style={{
            position: 'absolute', inset: 0,
            background: 'radial-gradient(circle at 25% 15%, rgba(255,255,255,0.55), transparent 38%), radial-gradient(circle at 80% 90%, rgba(255,255,255,0.25), transparent 45%)',
            pointerEvents: 'none',
          }} />
          {/* Diagonal shimmer streak */}
          <div style={{
            position: 'absolute', top: -40, left: -40, right: -40, bottom: -40,
            background: 'linear-gradient(115deg, transparent 38%, rgba(255,255,255,0.55) 48%, rgba(255,255,255,0.0) 58%)',
            animation: 'cxshimmer 3.6s ease-in-out infinite',
            pointerEvents: 'none',
            mixBlendMode: 'overlay',
          }} />
          {/* Twinkles */}
          {[
            { t: 24, l: 70, s: 16, d: 0 },
            { t: 140, l: 40, s: 11, d: 0.6 },
            { t: 90, l: 300, s: 10, d: 1.2 },
            { t: 280, l: 340, s: 14, d: 1.8 },
            { t: 360, l: 90, s: 10, d: 0.3 },
            { t: 460, l: 260, s: 12, d: 1.0 },
          ].map((s, si) => (
            <svg key={si} width={s.s} height={s.s} viewBox="0 0 24 24" style={{
              position: 'absolute', top: s.t, left: s.l, pointerEvents: 'none', zIndex: 1,
              animation: `cxtwinkle 2.4s ease-in-out ${s.d}s infinite`,
            }}>
              <path d="M12 0 L13.5 10.5 L24 12 L13.5 13.5 L12 24 L10.5 13.5 L0 12 L10.5 10.5 Z" fill="#fff" />
            </svg>
          ))}
          <div style={{ position: 'relative', zIndex: 2 }}>
            <div style={{ fontSize: 12, fontWeight: 700, opacity: 0.85, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 8 }}>Member · Founders Tier</div>
            <Wordmark size={32} mono />
          </div>
          <div style={{ position: 'relative', zIndex: 2 }}>
            <div style={{ fontSize: 56, fontWeight: 900, letterSpacing: -2, lineHeight: 0.95, textShadow: '0 4px 24px rgba(0,0,0,0.18)' }}>Unlimited<br />washes.</div>
            <div style={{ fontSize: 14, marginTop: 12, opacity: 0.9 }}>Every branch. Every day. One tap.</div>
          </div>
          <div style={{ position: 'relative', zIndex: 2, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ fontSize: 13, fontFamily: 'monospace', letterSpacing: 2 }}>•••• 2891</div>
            <div style={{ fontSize: 13, fontWeight: 700 }}>HJH SURIANA</div>
          </div>
        </div>
      </div>
    </section>
  );
}

// --- Testimonials ---
function Testimonials() {
  const items = [
    { name: 'Hjh Suriana A.', stars: 5, text: 'Eight minutes and my car looks new. The team at Tungku is always smiling. Worth every Ringgit.', source: 'Google Review' },
    { name: 'Daniel Wong', stars: 5, text: 'Live queue on the website saved me 20 minutes. Drove straight to Salar instead. Genius.', source: 'Google Review' },
    { name: 'Zarina M.', stars: 5, text: 'Three cars in the family — subscription would be a lifesaver. Hurry up Cuci Xpress!', source: 'Instagram' },
  ];
  return (
    <section style={{ padding: '96px 32px', background: CX.ink, color: '#fff' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto' }}>
        <div style={{ marginBottom: 48 }}>
          <Badge color="orange" size="md" style={{ marginBottom: 14 }}>What people say</Badge>
          <h2 style={{ fontSize: 48, fontWeight: 900, letterSpacing: -1, color: '#fff' }}>4.8 stars. 1,200+ reviews.</h2>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20 }}>
          {items.map((t, i) => (
            <div key={i} style={{ border: '1px solid #27272A', borderRadius: 16, padding: 28, background: '#18181B' }}>
              <div style={{ display: 'flex', gap: 2, marginBottom: 18 }}>
                {Array.from({length: t.stars}).map((_, si) => <Icon key={si} name="star" size={16} color={CX.yellow} style={{ fill: CX.yellow }} />)}
              </div>
              <div style={{ fontSize: 17, lineHeight: 1.55, marginBottom: 24 }}>&ldquo;{t.text}&rdquo;</div>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <Avatar name={t.name} size={36} />
                  <div style={{ fontSize: 14, fontWeight: 700 }}>{t.name}</div>
                </div>
                <div style={{ fontSize: 12, color: '#9CA3AF' }}>{t.source}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// --- Footer ---
function FooterBlock() {
  return (
    <footer style={{ background: '#000', color: '#fff', padding: '64px 32px 32px' }}>
      <div style={{ maxWidth: 1280, margin: '0 auto' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr', gap: 48, marginBottom: 48 }}>
          <div>
            <Wordmark size={32} />
            <div style={{ fontSize: 14, color: '#9CA3AF', marginTop: 16, lineHeight: 1.6, maxWidth: 360 }}>Xpress, Convenient, Clean — Guaranteed. Brunei&rsquo;s drive-thru car wash, building time-saving services for Bina Wawasan Negara.</div>
          </div>
          {[
            ['Services', ['Basic Wash', 'Full Package', 'Premium Detail', 'Subscriptions']],
            ['Company', ['About', 'Locations', 'Careers', 'Press']],
            ['Connect', ['+673 838 7000', 'cucixpress.bn@gmail.com', '@cucixpress (IG)', '@cucixpress (TT)']],
          ].map(([h, items]) => (
            <div key={h}>
              <div style={{ fontSize: 12, fontWeight: 800, color: '#fff', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 16 }}>{h}</div>
              <div style={{ display: 'grid', gap: 10 }}>{items.map(i => <div key={i} style={{ fontSize: 14, color: '#9CA3AF' }}>{i}</div>)}</div>
            </div>
          ))}
        </div>
        <div style={{ borderTop: '1px solid #27272A', paddingTop: 20, display: 'flex', justifyContent: 'space-between', fontSize: 12, color: '#6B7280' }}>
          <div>© 2026 Cuci Xpress Enterprise · Brunei Darussalam</div>
          <div>Built for BWN · Bina Wawasan Negara</div>
        </div>
      </div>
    </footer>
  );
}

window.LandingPage = LandingPage;
