// Customer Dashboard — wash history, vehicles, subscription.

function DashboardSurface({ tweaks, navigate }) {
  const [tab, setTab] = React.useState('overview');

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '240px 1fr', minHeight: '100%', background: CX.bgMuted }}>
      <DashSidebar tab={tab} setTab={setTab} navigate={navigate} />
      <div style={{ padding: '32px 40px' }}>
        {tab === 'overview' && <DashOverview navigate={navigate} />}
        {tab === 'history' && <DashHistory />}
        {tab === 'vehicles' && <DashVehicles />}
        {tab === 'subscription' && <DashSubscription />}
        {tab === 'receipts' && <DashReceipts />}
      </div>
    </div>
  );
}

function DashSidebar({ tab, setTab, navigate }) {
  const items = [
    { id: 'overview', label: 'Overview', icon: 'home' },
    { id: 'history', label: 'Wash history', icon: 'clock' },
    { id: 'vehicles', label: 'My vehicles', icon: 'car' },
    { id: 'subscription', label: 'Subscription', icon: 'crown' },
    { id: 'receipts', label: 'Receipts', icon: 'receipt' },
  ];
  return (
    <div style={{ background: '#fff', borderRight: '1px solid ' + CX.border, padding: '24px 16px', display: 'flex', flexDirection: 'column' }}>
      <div style={{ padding: '0 8px 24px', borderBottom: '1px solid ' + CX.border, marginBottom: 16 }}>
        <Wordmark size={22} />
      </div>
      <div style={{ display: 'grid', gap: 4 }}>
        {items.map(it => {
          const a = tab === it.id;
          return (
            <button key={it.id} onClick={() => setTab(it.id)} style={{
              display: 'flex', alignItems: 'center', gap: 12, padding: '10px 14px',
              background: a ? CX.primary10 : 'transparent', color: a ? CX.primary : CX.fg,
              border: 'none', borderRadius: 10, fontFamily: 'inherit', fontSize: 14, fontWeight: 600,
              cursor: 'pointer', textAlign: 'left',
            }}>
              <Icon name={it.icon} size={16} />{it.label}
            </button>
          );
        })}
      </div>
      <div style={{ marginTop: 'auto', borderTop: '1px solid ' + CX.border, paddingTop: 16 }}>
        <button onClick={() => navigate('landing')} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 12px', background: 'transparent', border: 'none', fontFamily: 'inherit', fontSize: 13, color: CX.fgMuted, cursor: 'pointer', width: '100%' }}>
          <Avatar name="Hjh Suriana" size={32} />
          <div style={{ textAlign: 'left' }}>
            <div style={{ fontWeight: 700, color: CX.fg, fontSize: 13 }}>Hjh Suriana A.</div>
            <div style={{ fontSize: 11 }}>Unlimited member</div>
          </div>
        </button>
      </div>
    </div>
  );
}

function DashOverview({ navigate }) {
  return (
    <div>
      <div style={{ marginBottom: 28 }}>
        <div style={{ fontSize: 13, color: CX.fgMuted, marginBottom: 4 }}>Welcome back,</div>
        <div style={{ fontSize: 36, fontWeight: 900, color: CX.ink, letterSpacing: -1 }}>Hjh Suriana 👋</div>
      </div>

      {/* Hero card — Pay & queue */}
      <div style={{
        background: `linear-gradient(135deg, ${CX.primary}, ${CX.secondary})`,
        borderRadius: 20, padding: 28, color: '#fff',
        border: '2px solid #000', boxShadow: CX.brutalist, marginBottom: 24,
        display: 'grid', gridTemplateColumns: '1fr auto', gap: 24, alignItems: 'center',
      }}>
        <div>
          <div style={{ fontSize: 12, fontWeight: 800, opacity: 0.85, textTransform: 'uppercase', letterSpacing: 2, marginBottom: 6 }}>One-tap wash</div>
          <div style={{ fontSize: 28, fontWeight: 900, letterSpacing: -0.5, marginBottom: 6 }}>Drive to Tungku Link, queue is short.</div>
          <div style={{ fontSize: 14, opacity: 0.9 }}>4 cars in queue · ~14 min wait · Your subscription covers this wash.</div>
        </div>
        <BrutalistButton color="#fff" fg={CX.ink} size="lg" onClick={() => navigate('queue')}>Pay &amp; Queue →</BrutalistButton>
      </div>

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 24 }}>
        {[
          { label: 'Washes this month', val: 6, hint: '↑ 2 vs last month', color: CX.primary },
          { label: 'Saved with subscription', val: 'BND 32', hint: 'vs pay-as-you-go', color: CX.green },
          { label: 'Lifetime washes', val: 47, hint: 'since Jan 2024', color: CX.fg },
          { label: 'Loyalty points', val: 1240, hint: '60 to free Premium', color: CX.secondary },
        ].map((s, i) => (
          <Card key={i} padding={20}>
            <div style={{ fontSize: 11, fontWeight: 700, color: CX.fgMuted, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 8 }}>{s.label}</div>
            <div style={{ fontSize: 32, fontWeight: 900, color: s.color, letterSpacing: -1, lineHeight: 1 }}>{s.val}</div>
            <div style={{ fontSize: 12, color: CX.fgMuted, marginTop: 6 }}>{s.hint}</div>
          </Card>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 16 }}>
        <Card padding={24}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 }}>
            <div style={{ fontSize: 18, fontWeight: 800 }}>Recent washes</div>
            <SoftButton variant="ghost" size="sm" iconRight="arrowRight">View all</SoftButton>
          </div>
          <div style={{ display: 'grid', gap: 10 }}>
            {RECENT_WASHES.slice(0, 4).map(w => (
              <div key={w.id} style={{ display: 'grid', gridTemplateColumns: '40px 1fr auto auto', gap: 14, alignItems: 'center', padding: '10px 0', borderBottom: '1px solid ' + CX.border }}>
                <div style={{ width: 40, height: 40, borderRadius: 10, background: CX.primary10, color: CX.primary, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <Icon name="droplet" size={18} />
                </div>
                <div>
                  <div style={{ fontSize: 14, fontWeight: 700, color: CX.fg }}>{w.package}</div>
                  <div style={{ fontSize: 12, color: CX.fgMuted }}>{w.branch} · {w.plate} · {w.date.split(' ')[0]}</div>
                </div>
                <Badge color={w.payment === 'Subscription' ? 'purple' : 'gray'} size="sm">{w.payment}</Badge>
                <div style={{ fontSize: 14, fontWeight: 800, color: CX.fg }}>BND {w.amount}</div>
              </div>
            ))}
          </div>
        </Card>
        <Card padding={24}>
          <div style={{ fontSize: 18, fontWeight: 800, marginBottom: 18 }}>Your subscription</div>
          <div style={{ background: CX.ink, color: '#fff', borderRadius: 14, padding: 20, marginBottom: 16 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
              <Badge color="orange">UNLIMITED</Badge>
              <Icon name="crown" size={20} color={CX.secondary} />
            </div>
            <div style={{ fontSize: 13, color: '#9CA3AF', marginBottom: 4 }}>Active until</div>
            <div style={{ fontSize: 22, fontWeight: 900 }}>May 28, 2026</div>
          </div>
          <div style={{ display: 'grid', gap: 8, fontSize: 13 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ color: CX.fgMuted }}>Plan</span><span style={{ fontWeight: 700 }}>Unlimited Xpress</span></div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ color: CX.fgMuted }}>Monthly</span><span style={{ fontWeight: 700 }}>BND 60</span></div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ color: CX.fgMuted }}>Used this month</span><span style={{ fontWeight: 700 }}>6 washes</span></div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ color: CX.fgMuted }}>Saved</span><span style={{ fontWeight: 700, color: CX.green }}>BND 32</span></div>
          </div>
        </Card>
      </div>
    </div>
  );
}

function DashHistory() {
  return (
    <div>
      <div style={{ marginBottom: 24, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <div style={{ fontSize: 36, fontWeight: 900, color: CX.ink, letterSpacing: -1 }}>Wash history</div>
          <div style={{ fontSize: 14, color: CX.fgMuted, marginTop: 4 }}>{RECENT_WASHES.length} washes · BND {RECENT_WASHES.reduce((a, b) => a + b.amount, 0)} total</div>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <SoftButton variant="outline" icon="filter">Filter</SoftButton>
          <SoftButton variant="outline" icon="download">Export CSV</SoftButton>
        </div>
      </div>

      <Card padding={0}>
        <div style={{ display: 'grid', gridTemplateColumns: '90px 1.2fr 1fr 1fr 110px 90px 50px', padding: '14px 24px', background: CX.bgMuted, fontSize: 11, fontWeight: 800, color: CX.fgMuted, textTransform: 'uppercase', letterSpacing: 0.5 }}>
          <div>ID</div><div>Date</div><div>Branch</div><div>Package</div><div>Vehicle</div><div style={{ textAlign: 'right' }}>Amount</div><div></div>
        </div>
        {RECENT_WASHES.map((w, i) => (
          <div key={w.id} style={{ display: 'grid', gridTemplateColumns: '90px 1.2fr 1fr 1fr 110px 90px 50px', padding: '16px 24px', alignItems: 'center', borderTop: i ? '1px solid ' + CX.border : 'none' }}>
            <div style={{ fontSize: 12, fontFamily: 'monospace', color: CX.fgMuted }}>{w.id}</div>
            <div style={{ fontSize: 14, color: CX.fg }}>{w.date}</div>
            <div style={{ fontSize: 14, fontWeight: 600, color: CX.fg }}>{w.branch}</div>
            <div><Badge color={w.package === 'Premium Detail' ? 'orange' : 'purple'}>{w.package}</Badge></div>
            <div style={{ fontSize: 12, fontFamily: 'monospace' }}>{w.plate}</div>
            <div style={{ fontSize: 14, fontWeight: 800, color: CX.fg, textAlign: 'right' }}>BND {w.amount}</div>
            <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
              <button style={{ background: 'transparent', border: 'none', cursor: 'pointer', color: CX.fgMuted }}><Icon name="moreHorizontal" /></button>
            </div>
          </div>
        ))}
      </Card>
    </div>
  );
}

function DashVehicles() {
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <div style={{ fontSize: 36, fontWeight: 900, color: CX.ink, letterSpacing: -1 }}>My vehicles</div>
        <BrutalistButton color={CX.primary} icon="plus">Add a car</BrutalistButton>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 16 }}>
        {VEHICLES.map((v, i) => (
          <Card key={v.plate} padding={24}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
              <Badge color={i === 0 ? 'purple' : 'gray'}>{i === 0 ? 'Default' : 'Family'}</Badge>
              <button style={{ background: 'transparent', border: 'none', cursor: 'pointer', color: CX.fgMuted }}><Icon name="edit" /></button>
            </div>
            <div style={{ height: 96, background: CX.bgMuted, borderRadius: 12, marginBottom: 16, display: 'flex', alignItems: 'center', justifyContent: 'center', color: CX.fgSubtle }}>
              <Icon name="car" size={56} />
            </div>
            <div style={{ fontSize: 24, fontWeight: 900, color: CX.ink, fontFamily: 'monospace', letterSpacing: -1 }}>{v.plate}</div>
            <div style={{ fontSize: 14, color: CX.fgMuted, marginBottom: 14 }}>{v.model} · {v.color}</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, padding: 14, background: CX.bgMuted, borderRadius: 10 }}>
              <div>
                <div style={{ fontSize: 11, color: CX.fgMuted, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5 }}>Total washes</div>
                <div style={{ fontSize: 20, fontWeight: 800, color: CX.primary }}>{v.washes}</div>
              </div>
              <div>
                <div style={{ fontSize: 11, color: CX.fgMuted, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5 }}>Last washed</div>
                <div style={{ fontSize: 14, fontWeight: 700, color: CX.fg, marginTop: 4 }}>{v.lastWash}</div>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

function DashSubscription() {
  return (
    <div>
      <div style={{ fontSize: 36, fontWeight: 900, color: CX.ink, letterSpacing: -1, marginBottom: 24 }}>Subscription</div>
      <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: 16 }}>
        <Card padding={28} style={{ background: CX.ink, color: '#fff', border: 'none' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 24 }}>
            <div>
              <Badge color="orange">UNLIMITED · ACTIVE</Badge>
              <div style={{ fontSize: 32, fontWeight: 900, marginTop: 14, letterSpacing: -1 }}>Unlimited Xpress</div>
              <div style={{ fontSize: 14, color: '#9CA3AF', marginTop: 4 }}>BND 60/mo · Renews May 28, 2026</div>
            </div>
            <Icon name="crown" size={36} color={CX.secondary} />
          </div>
          <div style={{ height: 1, background: '#27272A', margin: '12px 0 20px' }} />
          <div style={{ fontSize: 12, fontWeight: 700, color: '#9CA3AF', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 12 }}>This billing cycle</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16, marginBottom: 24 }}>
            {[['Washes', 6], ['Avg per week', 1.5], ['Saved', 'BND 32']].map(([l, v], i) => (
              <div key={i}>
                <div style={{ fontSize: 11, color: '#9CA3AF', textTransform: 'uppercase', letterSpacing: 0.5 }}>{l}</div>
                <div style={{ fontSize: 28, fontWeight: 900, color: i === 2 ? CX.green : '#fff' }}>{v}</div>
              </div>
            ))}
          </div>
          <div style={{ display: 'flex', gap: 10 }}>
            <SoftButton variant="ghost" style={{ color: '#fff', background: '#27272A' }}>Manage payment</SoftButton>
            <SoftButton variant="danger">Cancel plan</SoftButton>
          </div>
        </Card>
        <Card padding={24}>
          <div style={{ fontSize: 16, fontWeight: 800, marginBottom: 16 }}>Upgrade to Multi-Car Family</div>
          <div style={{ fontSize: 13, color: CX.fgMuted, marginBottom: 16, lineHeight: 1.6 }}>You have 2 vehicles registered. Family plan covers up to 3 cars for BND 150/mo.</div>
          <div style={{ background: CX.primary10, borderRadius: 10, padding: 14, marginBottom: 16 }}>
            <div style={{ fontSize: 12, color: CX.fgMuted }}>Difference</div>
            <div style={{ fontSize: 22, fontWeight: 900, color: CX.primary }}>+BND 90/mo</div>
            <div style={{ fontSize: 12, color: CX.fgMuted }}>Adds Honda Civic to your plan</div>
          </div>
          <BrutalistButton fullWidth color={CX.secondary} fg="#000">Upgrade plan</BrutalistButton>
        </Card>
      </div>
    </div>
  );
}

function DashReceipts() {
  return (
    <div>
      <div style={{ fontSize: 36, fontWeight: 900, color: CX.ink, letterSpacing: -1, marginBottom: 24 }}>Receipts</div>
      <Card padding={0}>
        {RECENT_WASHES.map((w, i) => (
          <div key={w.id} style={{ display: 'grid', gridTemplateColumns: '1fr auto auto', gap: 16, alignItems: 'center', padding: '20px 24px', borderTop: i ? '1px solid ' + CX.border : 'none' }}>
            <div>
              <div style={{ fontSize: 14, fontWeight: 700 }}>Receipt {w.id}</div>
              <div style={{ fontSize: 12, color: CX.fgMuted }}>{w.date} · {w.branch} · {w.package}</div>
            </div>
            <div style={{ fontSize: 16, fontWeight: 800 }}>BND {w.amount}</div>
            <SoftButton variant="outline" size="sm" icon="download">PDF</SoftButton>
          </div>
        ))}
      </Card>
    </div>
  );
}

window.DashboardSurface = DashboardSurface;
