// POS Surface — tablet, lane staff. Step-based: plate → package → addons → payment → receipt.

function POSSurface({ tweaks, navigate }) {
  const [step, setStep] = React.useState('plate');
  const [order, setOrder] = React.useState({ plate: '', branch: 'Tungku Link', pkg: null, addons: [], payment: null });

  const reset = () => { setOrder({ plate: '', branch: 'Tungku Link', pkg: null, addons: [], payment: null }); setStep('plate'); };

  return (
    <div style={{ background: '#0E0E14', minHeight: '100%', color: '#fff', display: 'grid', gridTemplateRows: 'auto 1fr', fontFamily: 'inherit' }}>
      {/* Top bar */}
      <div style={{ background: '#000', borderBottom: '1px solid #1F1F2A', padding: '14px 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
          <SoftButton variant="ghost" icon="chevronLeft" onClick={() => navigate('landing')} style={{ color: '#fff' }}>Exit</SoftButton>
          <div style={{ width: 1, height: 22, background: '#27272A' }} />
          <Wordmark size={22} mono /><span style={{ fontSize: 11, color: '#9CA3AF', fontWeight: 800, letterSpacing: 2 }}>POS</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, fontSize: 13 }}>
          <Badge color="orange">{order.branch}</Badge>
          <span style={{ color: '#9CA3AF' }}>Lane 1 · Crew: Aiman</span>
          <span style={{ color: '#9CA3AF' }}>{new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}</span>
        </div>
      </div>

      {/* Step indicator */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 380px', height: '100%' }}>
        <div style={{ padding: 32, overflowY: 'auto' }}>
          <PosSteps step={step} />
          <div style={{ marginTop: 32 }}>
            {step === 'plate' && <PlateStep order={order} setOrder={setOrder} next={() => setStep('package')} />}
            {step === 'package' && <PackageStep order={order} setOrder={setOrder} next={() => setStep('addons')} />}
            {step === 'addons' && <AddonStep order={order} setOrder={setOrder} next={() => setStep('payment')} />}
            {step === 'payment' && <PaymentStep order={order} setOrder={setOrder} next={() => setStep('done')} />}
            {step === 'done' && <DoneStep order={order} reset={reset} />}
          </div>
        </div>
        <PosSummary order={order} step={step} setStep={setStep} />
      </div>
    </div>
  );
}

const STEPS = [
  { id: 'plate', label: 'Plate' },
  { id: 'package', label: 'Package' },
  { id: 'addons', label: 'Add-ons' },
  { id: 'payment', label: 'Payment' },
  { id: 'done', label: 'Done' },
];

function PosSteps({ step }) {
  const idx = STEPS.findIndex(s => s.id === step);
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      {STEPS.map((s, i) => {
        const active = i === idx; const done = i < idx;
        return (
          <React.Fragment key={s.id}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{
                width: 32, height: 32, borderRadius: '50%',
                background: done ? CX.green : active ? CX.primary : '#1F1F2A',
                color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontWeight: 800, fontSize: 13,
              }}>{done ? <Icon name="check" size={16} strokeWidth={3} /> : i + 1}</div>
              <div style={{ fontSize: 13, fontWeight: 700, color: active || done ? '#fff' : '#6B7280', letterSpacing: 1, textTransform: 'uppercase' }}>{s.label}</div>
            </div>
            {i < STEPS.length - 1 && <div style={{ height: 2, flex: 1, background: done ? CX.green : '#1F1F2A' }} />}
          </React.Fragment>
        );
      })}
    </div>
  );
}

function PlateStep({ order, setOrder, next }) {
  const [v, setV] = React.useState(order.plate);
  const tap = (c) => setV(p => (p + c).slice(0, 8));
  const back = () => setV(p => p.slice(0, -1));
  const commit = () => { setOrder(o => ({ ...o, plate: v })); next(); };
  const recents = ['KB 2891', 'KA 0142', 'BFA 7712'];
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1.2fr 1fr', gap: 32 }}>
      <div>
        <div style={{ fontSize: 28, fontWeight: 900, marginBottom: 8 }}>Enter plate number</div>
        <div style={{ fontSize: 14, color: '#9CA3AF', marginBottom: 24 }}>Or scan with the lane camera (auto-detect available).</div>

        <div style={{
          background: '#fff', color: '#000', border: '4px solid #FFE800',
          borderRadius: 14, padding: '28px 24px', textAlign: 'center', marginBottom: 16,
          fontFamily: 'monospace', fontSize: 64, fontWeight: 900, letterSpacing: 4, minHeight: 96,
        }}>{v || <span style={{ color: '#D1D5DB' }}>KB 0000</span>}</div>

        {/* Keypad */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 6 }}>
          {'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').map(c => (
            <button key={c} onClick={() => tap(c)} style={padBtn}>{c}</button>
          ))}
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(10, 1fr)', gap: 6, marginTop: 6 }}>
          {'0123456789'.split('').map(c => (
            <button key={c} onClick={() => tap(c)} style={{ ...padBtn, background: '#27272A' }}>{c}</button>
          ))}
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 6, marginTop: 6 }}>
          <button onClick={() => tap(' ')} style={{ ...padBtn, background: '#27272A' }}>SPACE</button>
          <button onClick={back} style={{ ...padBtn, background: '#7F1D1D' }}>← BACKSPACE</button>
          <button onClick={() => setV('')} style={{ ...padBtn, background: '#27272A' }}>CLEAR</button>
        </div>
      </div>
      <div>
        <div style={{ fontSize: 13, fontWeight: 800, color: '#9CA3AF', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 12 }}>Recent vehicles</div>
        <div style={{ display: 'grid', gap: 8, marginBottom: 28 }}>
          {recents.map(r => (
            <button key={r} onClick={() => setV(r)} style={{ background: '#1F1F2A', border: '1px solid #27272A', borderRadius: 12, padding: '14px 18px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontFamily: 'inherit', cursor: 'pointer', color: '#fff' }}>
              <div>
                <div style={{ fontSize: 18, fontWeight: 800, fontFamily: 'monospace' }}>{r}</div>
                <div style={{ fontSize: 11, color: '#9CA3AF' }}>Member · last washed Apr 22</div>
              </div>
              <Icon name="chevronRight" />
            </button>
          ))}
        </div>
        <div style={{ background: '#18181B', border: '1px dashed #27272A', borderRadius: 14, padding: 20, textAlign: 'center', marginBottom: 16 }}>
          <Icon name="eye" size={32} color={CX.primary} />
          <div style={{ fontSize: 14, fontWeight: 700, marginTop: 10 }}>Auto-scan from lane camera</div>
          <div style={{ fontSize: 12, color: '#9CA3AF', marginTop: 4 }}>Detects Brunei plates automatically</div>
        </div>
        <BrutalistButton fullWidth color={CX.primary} size="lg" onClick={commit}>Continue →</BrutalistButton>
      </div>
    </div>
  );
}

const padBtn = {
  background: '#1F1F2A', color: '#fff', border: '1px solid #27272A', borderRadius: 8,
  fontSize: 18, fontWeight: 700, fontFamily: 'inherit', padding: '14px 0', cursor: 'pointer',
};

function PackageStep({ order, setOrder, next }) {
  return (
    <div>
      <div style={{ fontSize: 28, fontWeight: 900, marginBottom: 8 }}>Pick a package</div>
      <div style={{ fontSize: 14, color: '#9CA3AF', marginBottom: 28 }}>For plate <span style={{ color: '#fff', fontFamily: 'monospace', fontWeight: 700 }}>{order.plate || 'unknown'}</span></div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
        {PACKAGES.map(p => (
          <button key={p.id} onClick={() => { setOrder(o => ({ ...o, pkg: p })); next(); }} style={{
            background: '#fff', color: '#000', border: '4px solid ' + (p.popular ? CX.secondary : '#000'),
            borderRadius: 18, padding: 24, textAlign: 'left', cursor: 'pointer', fontFamily: 'inherit',
            position: 'relative', boxShadow: '8px 8px 0 0 rgba(0,0,0,0.92)',
          }}>
            {p.popular && <div style={{ position: 'absolute', top: -10, right: 16, background: CX.secondary, color: '#000', fontSize: 11, fontWeight: 800, padding: '4px 12px', borderRadius: 999, border: '2px solid #000' }}>POPULAR</div>}
            <div style={{ fontSize: 12, fontWeight: 800, color: p.color, textTransform: 'uppercase', letterSpacing: 1.5, marginBottom: 8 }}>{p.name}</div>
            <div style={{ fontSize: 64, fontWeight: 900, letterSpacing: -2, lineHeight: 1, marginBottom: 6 }}>BND {p.price}</div>
            <div style={{ fontSize: 13, color: CX.fgMuted, marginBottom: 18 }}>~{p.duration} minutes</div>
            <div style={{ display: 'grid', gap: 6 }}>
              {p.features.map((f, i) => <div key={i} style={{ fontSize: 13, display: 'flex', alignItems: 'center', gap: 8 }}><Icon name="check" size={14} color={CX.green} strokeWidth={3} />{f}</div>)}
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

function AddonStep({ order, setOrder, next }) {
  const addons = [
    { id: 'tire', name: 'Tire Shine', price: 3 },
    { id: 'fragrance', name: 'Cabin Fragrance', price: 2 },
    { id: 'rainx', name: 'Rain-X Treatment', price: 5 },
    { id: 'mat', name: 'Floor Mat Wash', price: 4 },
  ];
  const toggle = (a) => setOrder(o => ({
    ...o,
    addons: o.addons.find(x => x.id === a.id) ? o.addons.filter(x => x.id !== a.id) : [...o.addons, a],
  }));
  return (
    <div>
      <div style={{ fontSize: 28, fontWeight: 900, marginBottom: 8 }}>Add-ons (optional)</div>
      <div style={{ fontSize: 14, color: '#9CA3AF', marginBottom: 28 }}>Quick taps. Skip if none.</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 12 }}>
        {addons.map(a => {
          const on = order.addons.find(x => x.id === a.id);
          return (
            <button key={a.id} onClick={() => toggle(a)} style={{
              background: on ? CX.primary : '#1F1F2A', color: '#fff',
              border: '2px solid ' + (on ? CX.secondary : '#27272A'),
              borderRadius: 14, padding: 24, textAlign: 'left', cursor: 'pointer', fontFamily: 'inherit',
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            }}>
              <div>
                <div style={{ fontSize: 18, fontWeight: 800 }}>{a.name}</div>
                <div style={{ fontSize: 12, color: on ? '#FBE89E' : '#9CA3AF' }}>+ BND {a.price}</div>
              </div>
              <div style={{ width: 32, height: 32, borderRadius: 8, border: '2px solid ' + (on ? CX.secondary : '#374151'), background: on ? CX.secondary : 'transparent', color: '#000', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                {on && <Icon name="check" size={18} strokeWidth={3} />}
              </div>
            </button>
          );
        })}
      </div>
      <div style={{ marginTop: 24, display: 'flex', gap: 12 }}>
        <SoftButton variant="ghost" style={{ color: '#fff' }} onClick={next}>Skip add-ons</SoftButton>
        <BrutalistButton color={CX.primary} size="lg" onClick={next}>Continue to payment →</BrutalistButton>
      </div>
    </div>
  );
}

function PaymentStep({ order, setOrder, next }) {
  const total = (order.pkg?.price || 0) + order.addons.reduce((a, b) => a + b.price, 0);
  const methods = [
    { id: 'cash', label: 'Cash', icon: 'cash', tone: '#22C55E' },
    { id: 'card', label: 'Card', icon: 'creditCard', tone: CX.blue },
    { id: 'qr', label: 'QR Pay', icon: 'qr', tone: CX.primary },
    { id: 'sub', label: 'Subscription', icon: 'crown', tone: CX.secondary },
    { id: 'voucher', label: 'Voucher', icon: 'gift', tone: CX.pink },
  ];
  const [m, setM] = React.useState(null);
  const pay = () => { setOrder(o => ({ ...o, payment: methods.find(x => x.id === m) })); next(); };
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 28 }}>
      <div>
        <div style={{ fontSize: 28, fontWeight: 900, marginBottom: 8 }}>Payment method</div>
        <div style={{ fontSize: 14, color: '#9CA3AF', marginBottom: 24 }}>Total due <span style={{ color: '#fff', fontWeight: 800 }}>BND {total}</span></div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 12 }}>
          {methods.map(x => {
            const on = m === x.id;
            return (
              <button key={x.id} onClick={() => setM(x.id)} style={{
                background: on ? x.tone : '#1F1F2A', color: '#fff',
                border: '2px solid ' + (on ? '#fff' : '#27272A'),
                borderRadius: 14, padding: 24, fontFamily: 'inherit', cursor: 'pointer',
                display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 12,
              }}>
                <Icon name={x.icon} size={32} />
                <div style={{ fontSize: 18, fontWeight: 800 }}>{x.label}</div>
              </button>
            );
          })}
        </div>
      </div>
      <div>
        <div style={{ background: '#1F1F2A', borderRadius: 16, padding: 24, marginBottom: 16 }}>
          <div style={{ fontSize: 12, fontWeight: 800, color: '#9CA3AF', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 14 }}>Order</div>
          <div style={{ display: 'grid', gap: 10, marginBottom: 14 }}>
            <Row label={order.pkg?.name} value={'BND ' + order.pkg?.price} />
            {order.addons.map(a => <Row key={a.id} label={'+ ' + a.name} value={'BND ' + a.price} muted />)}
          </div>
          <div style={{ height: 1, background: '#27272A', margin: '12px 0' }} />
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 36, fontWeight: 900, letterSpacing: -1 }}>
            <span>Total</span><span style={{ color: CX.secondary }}>BND {total}</span>
          </div>
        </div>
        <BrutalistButton fullWidth size="lg" color={CX.green} disabled={!m} onClick={pay}>Charge BND {total} →</BrutalistButton>
      </div>
    </div>
  );
}

function Row({ label, value, muted }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14, color: muted ? '#9CA3AF' : '#fff' }}>
      <span>{label}</span><span style={{ fontWeight: 700 }}>{value}</span>
    </div>
  );
}

function DoneStep({ order, reset }) {
  const total = (order.pkg?.price || 0) + order.addons.reduce((a, b) => a + b.price, 0);
  return (
    <div style={{ display: 'grid', placeItems: 'center', textAlign: 'center', paddingTop: 40 }}>
      <div style={{ width: 96, height: 96, borderRadius: '50%', background: CX.green, display: 'grid', placeItems: 'center', marginBottom: 20, animation: 'cxpulse 1.4s' }}>
        <Icon name="check" size={56} strokeWidth={4} color="#000" />
      </div>
      <div style={{ fontSize: 40, fontWeight: 900, letterSpacing: -1 }}>Payment received</div>
      <div style={{ fontSize: 16, color: '#9CA3AF', marginTop: 6 }}>BND {total} via {order.payment?.label}</div>
      <div style={{ background: '#1F1F2A', borderRadius: 14, padding: 20, marginTop: 24, minWidth: 320 }}>
        <div style={{ fontSize: 12, fontWeight: 800, color: '#9CA3AF', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 8 }}>Queue ticket</div>
        <div style={{ fontSize: 56, fontWeight: 900, fontFamily: 'monospace', color: CX.secondary, letterSpacing: -2 }}>A30</div>
        <div style={{ fontSize: 14, color: '#9CA3AF', marginTop: 4 }}>{order.plate} · ETA ~12 min</div>
      </div>
      <div style={{ marginTop: 24, display: 'flex', gap: 12 }}>
        <SoftButton variant="ghost" icon="receipt" style={{ color: '#fff', background: '#27272A' }}>Print receipt</SoftButton>
        <BrutalistButton color={CX.primary} size="lg" onClick={reset}>Next customer →</BrutalistButton>
      </div>
    </div>
  );
}

function PosSummary({ order, step, setStep }) {
  const total = (order.pkg?.price || 0) + order.addons.reduce((a, b) => a + b.price, 0);
  return (
    <div style={{ background: '#000', borderLeft: '1px solid #1F1F2A', padding: 24, display: 'flex', flexDirection: 'column' }}>
      <div style={{ fontSize: 11, fontWeight: 800, color: '#9CA3AF', letterSpacing: 2, textTransform: 'uppercase', marginBottom: 16 }}>Live ticket</div>
      <div style={{ background: '#1F1F2A', borderRadius: 14, padding: 18, marginBottom: 16 }}>
        <div style={{ fontSize: 11, color: '#9CA3AF', textTransform: 'uppercase', letterSpacing: 1, fontWeight: 700, marginBottom: 6 }}>Plate</div>
        <div style={{ fontSize: 32, fontWeight: 900, fontFamily: 'monospace', color: '#fff', letterSpacing: -1 }}>{order.plate || '—'}</div>
        <button onClick={() => setStep('plate')} style={{ background: 'transparent', border: 'none', color: CX.primary, fontSize: 11, fontWeight: 700, marginTop: 4, cursor: 'pointer', padding: 0, fontFamily: 'inherit' }}>Edit</button>
      </div>
      <div style={{ display: 'grid', gap: 10, marginBottom: 16 }}>
        <SumRow k="Package" v={order.pkg?.name || '—'} edit={() => setStep('package')} />
        <SumRow k="Add-ons" v={order.addons.length ? order.addons.map(a => a.name).join(', ') : 'None'} edit={() => setStep('addons')} />
        <SumRow k="Payment" v={order.payment?.label || '—'} />
      </div>
      <div style={{ marginTop: 'auto' }}>
        <div style={{ fontSize: 11, color: '#9CA3AF', textTransform: 'uppercase', letterSpacing: 1, fontWeight: 700 }}>Total</div>
        <div style={{ fontSize: 56, fontWeight: 900, color: CX.secondary, letterSpacing: -2, lineHeight: 1, marginTop: 4 }}>BND {total}</div>
        <div style={{ fontSize: 12, color: '#6B7280', marginTop: 6 }}>Step {STEPS.findIndex(s => s.id === step) + 1} of {STEPS.length}</div>
      </div>
    </div>
  );
}

function SumRow({ k, v, edit }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '90px 1fr auto', alignItems: 'center', gap: 8, fontSize: 13 }}>
      <span style={{ color: '#9CA3AF', textTransform: 'uppercase', fontSize: 10, fontWeight: 700, letterSpacing: 1 }}>{k}</span>
      <span style={{ color: '#fff', fontWeight: 600 }}>{v}</span>
      {edit && <button onClick={edit} style={{ background: 'transparent', border: 'none', color: CX.primary, fontSize: 11, cursor: 'pointer', padding: 0, fontFamily: 'inherit', fontWeight: 700 }}>Edit</button>}
    </div>
  );
}

window.POSSurface = POSSurface;
