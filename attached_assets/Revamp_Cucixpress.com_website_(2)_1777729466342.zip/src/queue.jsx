// Live Queue surface — public + branch big-screen modes.

function QueueSurface({ tweaks, navigate }) {
  const [mode, setMode] = React.useState('public'); // 'public' | 'bigscreen'
  const [selected, setSelected] = React.useState('tungku');
  const [queue, setQueue] = React.useState(QUEUE_NOW);
  const [ticker, setTicker] = React.useState(0);

  // Simulate live progression
  React.useEffect(() => {
    const id = setInterval(() => {
      setQueue(prev => {
        const next = prev.map(c => ({ ...c }));
        // advance washing cars
        next.forEach(c => {
          if (c.stage === 'washing') c.progress = Math.min(1, c.progress + 0.04);
        });
        // promote first queued if a washing one finishes
        const finished = next.find(c => c.stage === 'washing' && c.progress >= 1);
        if (finished) {
          finished.stage = 'done';
          const nextQueued = next.find(c => c.stage === 'queued');
          if (nextQueued) { nextQueued.stage = 'washing'; nextQueued.progress = 0.05; }
        }
        return next.filter(c => c.stage !== 'done').concat(next.filter(c => c.stage === 'done'));
      });
      setTicker(t => t + 1);
    }, 1500);
    return () => clearInterval(id);
  }, []);

  if (mode === 'bigscreen') return <BigScreen queue={queue} branch={BRANCHES.find(b => b.id === selected)} onExit={() => setMode('public')} />;

  const branch = BRANCHES.find(b => b.id === selected);

  return (
    <div style={{ background: CX.bgMuted, minHeight: '100%', paddingBottom: 80 }}>
      <div style={{ background: '#fff', borderBottom: '1px solid ' + CX.border, padding: '20px 32px', position: 'sticky', top: 0, zIndex: 10 }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
            <SoftButton variant="ghost" icon="chevronLeft" onClick={() => navigate('landing')}>Back</SoftButton>
            <div>
              <div style={{ fontSize: 12, fontWeight: 700, color: CX.fgMuted, letterSpacing: 1, textTransform: 'uppercase' }}>Cuci Xpress · Live</div>
              <div style={{ fontSize: 22, fontWeight: 900, color: CX.ink }}>Queue across all branches</div>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            <Badge color="green" size="lg">
              <span style={{ width: 6, height: 6, borderRadius: '50%', background: CX.green, animation: 'cxpulse 1.6s infinite' }} />
              Live · {new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}
            </Badge>
            <SoftButton variant="dark" size="md" icon="grid" onClick={() => setMode('bigscreen')}>Big-screen mode</SoftButton>
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 1280, margin: '0 auto', padding: '32px', display: 'grid', gridTemplateColumns: '320px 1fr', gap: 24 }}>
        {/* Branch selector list */}
        <div style={{ display: 'grid', gap: 10, alignContent: 'start' }}>
          <div style={{ fontSize: 11, fontWeight: 800, color: CX.fgMuted, textTransform: 'uppercase', letterSpacing: 1, padding: '4px 8px' }}>Choose a branch</div>
          {BRANCHES.map(b => {
            const active = selected === b.id;
            return (
              <button key={b.id} onClick={() => setSelected(b.id)} style={{
                background: active ? CX.primary10 : '#fff',
                color: CX.fg,
                border: '2px solid ' + (active ? CX.primary : CX.border),
                borderRadius: 14, padding: 16, textAlign: 'left', cursor: 'pointer',
                boxShadow: active ? '4px 4px 0 0 ' + CX.primary : 'none',
                fontFamily: 'inherit', transition: 'all 0.15s',
                display: 'grid', gridTemplateColumns: '1fr auto', gap: 8,
              }}>
                <div>
                  <div style={{ fontSize: 15, fontWeight: 800, color: active ? CX.primary : CX.fg }}>{b.name}</div>
                  <div style={{ fontSize: 11, color: CX.fgMuted, marginTop: 2 }}>{b.queue} in queue · {b.washing} washing</div>
                </div>
                <div style={{ fontSize: 18, fontWeight: 900, color: b.eta < 10 ? CX.green : b.eta < 20 ? CX.secondary : CX.red }}>
                  {b.eta === 0 ? 'Open' : b.eta + 'm'}
                </div>
              </button>
            );
          })}
        </div>

        {/* Detail */}
        <div style={{ display: 'grid', gap: 16 }}>
          <Card padding={32}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 }}>
              <div>
                <div style={{ fontSize: 12, fontWeight: 700, color: CX.secondary, textTransform: 'uppercase', letterSpacing: 1 }}>{branch.flag || 'Branch'}</div>
                <div style={{ fontSize: 36, fontWeight: 900, color: CX.ink, letterSpacing: -1 }}>{branch.name}</div>
                <div style={{ fontSize: 14, color: CX.fgMuted, marginTop: 4 }}>{branch.address}</div>
              </div>
              <BrutalistButton color={CX.primary} size="md" onClick={() => navigate('pos')}>Pay &amp; Join Queue →</BrutalistButton>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 24 }}>
              {[
                { label: 'Cars in queue', value: branch.queue, color: CX.primary },
                { label: 'Estimated wait', value: branch.eta + 'm', color: branch.eta < 10 ? CX.green : CX.secondary },
                { label: 'Washing now', value: branch.washing + '/' + branch.capacity, color: CX.fg },
                { label: 'Today total', value: branch.todayCars, color: CX.fg },
              ].map((s, i) => (
                <div key={i} style={{ background: CX.bgMuted, borderRadius: 12, padding: 16 }}>
                  <div style={{ fontSize: 11, fontWeight: 700, color: CX.fgMuted, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 6 }}>{s.label}</div>
                  <div style={{ fontSize: 32, fontWeight: 900, color: s.color, letterSpacing: -1 }}>{s.value}</div>
                </div>
              ))}
            </div>

            {/* Lane visualization */}
            <div style={{ fontSize: 11, fontWeight: 800, color: CX.fgMuted, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 12 }}>Wash lane · live</div>
            <div style={{ position: 'relative', background: CX.ink, borderRadius: 16, padding: '24px 28px', overflow: 'hidden' }}>
              {/* lane stripes */}
              <div style={{ position: 'absolute', inset: 0, backgroundImage: 'repeating-linear-gradient(90deg, transparent 0 32px, rgba(255,255,255,0.05) 32px 64px)' }} />
              <div style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: 8 }}>
                {/* Direction arrow */}
                <div style={{ color: '#374151', fontSize: 11, fontWeight: 700, letterSpacing: 1 }}>ENTRY →</div>
                <div style={{ flex: 1, display: 'flex', gap: 8, alignItems: 'center', overflow: 'hidden' }}>
                  {queue.slice(0, 6).map((c, i) => {
                    const washing = c.stage === 'washing';
                    return (
                      <div key={c.id} style={{
                        flex: '0 0 auto',
                        background: washing ? CX.primary : '#27272A',
                        borderRadius: 10, padding: '10px 14px',
                        border: washing ? '2px solid ' + CX.secondary : '2px solid transparent',
                        minWidth: 140,
                      }}>
                        <div style={{ fontSize: 10, fontWeight: 700, color: washing ? '#FBE89E' : '#9CA3AF', textTransform: 'uppercase', letterSpacing: 1 }}>
                          {washing ? 'WASHING' : '#' + (i + 1) + ' QUEUED'}
                        </div>
                        <div style={{ fontSize: 16, fontWeight: 800, color: '#fff', fontFamily: 'monospace' }}>{c.plate}</div>
                        <div style={{ fontSize: 11, color: washing ? '#FFE4B5' : '#9CA3AF', marginTop: 2 }}>{c.package} · {c.customer}</div>
                        {washing && (
                          <div style={{ marginTop: 8, height: 4, background: 'rgba(0,0,0,0.3)', borderRadius: 999, overflow: 'hidden' }}>
                            <div style={{ height: '100%', width: (c.progress * 100) + '%', background: CX.secondary, borderRadius: 999, transition: 'width 0.4s ease' }} />
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
                <div style={{ color: '#374151', fontSize: 11, fontWeight: 700, letterSpacing: 1 }}>← EXIT</div>
              </div>
            </div>
          </Card>

          <Card padding={28}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 }}>
              <div style={{ fontSize: 18, fontWeight: 800, color: CX.fg }}>Smart suggestion</div>
              <Badge color="purple">Powered by traffic data</Badge>
            </div>
            <div style={{ background: CX.primary10, borderRadius: 12, padding: 20, display: 'flex', alignItems: 'center', gap: 16 }}>
              <div style={{ width: 56, height: 56, borderRadius: '50%', background: CX.primary, color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                <Icon name="zap" size={28} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 16, fontWeight: 800, color: CX.fg }}>Tutong is empty right now</div>
                <div style={{ fontSize: 13, color: CX.fgMuted }}>If you&rsquo;re flexible, drive 8 minutes further and skip the queue completely.</div>
              </div>
              <SoftButton variant="primary" iconRight="arrowRight" onClick={() => setSelected('tutong')}>Switch</SoftButton>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

// --- Big screen mode (in-branch TV) ---
function BigScreen({ queue, branch, onExit }) {
  const washing = queue.filter(c => c.stage === 'washing');
  const next = queue.filter(c => c.stage === 'queued').slice(0, 5);
  return (
    <div style={{ background: '#000', color: '#fff', minHeight: '100%', padding: 48, fontFamily: 'inherit', position: 'relative', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', top: 24, right: 24 }}>
        <SoftButton variant="ghost" icon="x" onClick={onExit} style={{ color: '#fff' }}>Exit</SoftButton>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 56 }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 8 }}>
            <span style={{ width: 14, height: 14, borderRadius: '50%', background: CX.green, animation: 'cxpulse 1.6s infinite' }} />
            <span style={{ fontSize: 16, fontWeight: 800, letterSpacing: 4, color: '#9CA3AF' }}>LIVE QUEUE</span>
          </div>
          <Wordmark size={56} mono />
          <div style={{ fontSize: 28, fontWeight: 700, color: CX.secondary, marginTop: 8 }}>{branch.name}</div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontSize: 96, fontWeight: 900, lineHeight: 1, fontFeatureSettings: '"tnum"' }}>{new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}</div>
          <div style={{ fontSize: 18, color: '#9CA3AF', marginTop: 4 }}>{branch.todayCars} cars today</div>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 32 }}>
        <div>
          <div style={{ fontSize: 18, fontWeight: 800, letterSpacing: 4, color: '#9CA3AF', marginBottom: 20 }}>NOW WASHING</div>
          <div style={{ display: 'grid', gap: 16 }}>
            {washing.map(c => (
              <div key={c.id} style={{ background: CX.primary, borderRadius: 24, padding: '32px 40px', border: '4px solid ' + CX.secondary }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
                  <div style={{ fontSize: 96, fontWeight: 900, fontFamily: 'monospace', letterSpacing: -2, lineHeight: 1 }}>{c.plate}</div>
                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: 16, fontWeight: 800, color: '#FBE89E', letterSpacing: 1 }}>{c.package.toUpperCase()}</div>
                    <div style={{ fontSize: 56, fontWeight: 900, color: '#fff' }}>{Math.round(c.progress * 100)}<span style={{ fontSize: 24 }}>%</span></div>
                  </div>
                </div>
                <div style={{ height: 12, background: 'rgba(0,0,0,0.3)', borderRadius: 999, overflow: 'hidden' }}>
                  <div style={{ height: '100%', width: (c.progress * 100) + '%', background: CX.secondary, borderRadius: 999, transition: 'width 0.4s' }} />
                </div>
              </div>
            ))}
            {washing.length === 0 && (
              <div style={{ background: '#18181B', borderRadius: 24, padding: 80, textAlign: 'center', fontSize: 32, fontWeight: 800, color: '#374151' }}>Lane open · drive in</div>
            )}
          </div>
        </div>

        <div>
          <div style={{ fontSize: 18, fontWeight: 800, letterSpacing: 4, color: '#9CA3AF', marginBottom: 20 }}>UP NEXT</div>
          <div style={{ display: 'grid', gap: 12 }}>
            {next.map((c, i) => (
              <div key={c.id} style={{ display: 'grid', gridTemplateColumns: '64px 1fr auto', alignItems: 'center', gap: 20, padding: '16px 20px', background: '#18181B', borderRadius: 16, border: '1px solid #27272A' }}>
                <div style={{ fontSize: 48, fontWeight: 900, color: i === 0 ? CX.secondary : '#374151', lineHeight: 1 }}>{i + 1}</div>
                <div>
                  <div style={{ fontSize: 28, fontWeight: 900, fontFamily: 'monospace' }}>{c.plate}</div>
                  <div style={{ fontSize: 13, color: '#9CA3AF' }}>{c.package}</div>
                </div>
                <div style={{ fontSize: 14, fontWeight: 700, color: '#9CA3AF' }}>~{(i + 1) * 6}m</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, background: '#18181B', padding: '16px 48px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderTop: '1px solid #27272A' }}>
        <div style={{ fontSize: 14, color: '#9CA3AF' }}>cucixpress.com / queue · live updates every 2 seconds</div>
        <div style={{ fontSize: 14, color: '#9CA3AF' }}>Estimated wait now: <span style={{ color: CX.secondary, fontWeight: 800 }}>~{branch.eta}m</span></div>
      </div>
    </div>
  );
}

window.QueueSurface = QueueSurface;
