# Cuci Xpress — All-in-One Web App (Design Prototype)

A high-fidelity HTML/React prototype of the revamped **cucixpress.com** covering five surfaces:

1. **Landing page** — marketing site with live queue widget, packages, branches, subscription tease
2. **Live Queue** — public queue page + big-screen TV mode for branches
3. **Customer Dashboard** — wash history, vehicles, subscription, receipts
4. **Point of Sale (POS)** — tablet flow for lane staff: plate → package → add-ons → payment → ticket
5. **CRM** — admin: customers, subscriptions, branches, campaigns

The whole prototype runs from a single `Cuci Xpress Revamp.html` file using React 18 + Babel-in-the-browser. No build step required to **view** it.

---

## 🚀 Quick start (just view the prototype)

You can drop this folder into Replit as-is and serve it as a static site. No npm install, no build.

### Option A — Replit "HTML, CSS, JS" template (simplest)

1. In Replit, click **Create Repl** → choose the **HTML, CSS, JS** template.
2. Open the three-dot menu → **Upload folder** → upload this entire unzipped folder (or upload the `.zip` and extract in the Repl shell with `unzip cuci-xpress.zip`).
3. Rename `Cuci Xpress Revamp.html` to `index.html` (Replit's static server looks for `index.html`):
   ```bash
   mv "Cuci Xpress Revamp.html" index.html
   ```
4. Click **Run**. Replit serves the static files and opens the preview.

### Option B — Replit "Static" / Node template with a tiny server

If you want explicit control or plan to add a backend later:

1. Create a **Node.js** Repl.
2. Upload all files from this folder.
3. Add a `package.json`:
   ```json
   {
     "name": "cuci-xpress",
     "version": "1.0.0",
     "scripts": {
       "start": "npx serve -l 3000 ."
     }
   }
   ```
4. Add a `.replit` file:
   ```
   run = "npm start"
   ```
5. Click **Run**. Open the preview, navigate to `Cuci Xpress Revamp.html` (or rename it to `index.html`).

---

## 📁 File structure

```
cuci-xpress/
├── Cuci Xpress Revamp.html   ← Entry point. Loads React + all surfaces.
├── README.md                  ← This file.
├── tweaks-panel.jsx           ← Floating "Tweaks" UI (theme, density, accent).
└── src/
    ├── tokens.css             ← Brand colors + typography (CSS variables).
    ├── shared.jsx             ← Surface switcher, icons, badges, buttons, wordmark.
    ├── landing.jsx            ← Landing page (hero, packages, branches, subs, footer).
    ├── queue.jsx              ← Live queue + big-screen TV mode.
    ├── dashboard.jsx          ← Customer dashboard (history, vehicles, subscription).
    ├── pos.jsx                ← Point-of-sale tablet flow.
    └── crm.jsx                ← Admin CRM (customers, subscriptions, branches).
```

### How the surfaces are wired

`Cuci Xpress Revamp.html` mounts a single React app. The bottom-of-screen **surface switcher** (or `#landing`, `#queue`, `#dashboard`, `#pos`, `#crm` URL hashes) flips between surfaces. Each surface is a self-contained component in `src/<name>.jsx`.

All `.jsx` files are loaded as `<script type="text/babel">` and transpiled in the browser.

---

## 🎨 Design tokens

`src/tokens.css` defines brand colors and typography as CSS variables. Component files also reference a `CX` JS object in `src/shared.jsx` that mirrors the same palette. **If you change a color, change it in both places** (or refactor `shared.jsx` to read from `getComputedStyle(document.documentElement)`).

Key tokens:

| Token         | Value     | Use                              |
| ------------- | --------- | -------------------------------- |
| `--cx-primary`| `#7C5CE7` | Brand purple (CTAs, accents)     |
| `--cx-secondary`| `#FF9500` | Secondary orange (highlights)  |
| `--cx-ink`    | `#0A0A0A` | Near-black for headlines         |
| `--cx-fg`     | `#111827` | Body text                        |
| `--cx-bg`     | `#F9FAFB` | Page background                  |

---

## 🏗 Migrating from prototype to production

The prototype uses **Babel-in-the-browser** for fast iteration. For production you should switch to a real bundler so the app loads fast and tree-shakes properly.

### Recommended: migrate to Vite + React in Replit

1. In Replit, **Create Repl** → choose the **Vite (React)** template, OR run in shell:
   ```bash
   npm create vite@latest cuci-xpress -- --template react
   cd cuci-xpress
   npm install
   ```
2. Move files:
   - `src/*.jsx` → `src/` (rename to `.jsx` files Vite already understands)
   - `src/tokens.css` → `src/tokens.css`, then `import './tokens.css'` from `main.jsx`
   - `Cuci Xpress Revamp.html` → use as a reference; replace Vite's default `index.html` mount + `App.jsx` to render the surface switcher
3. Replace `Object.assign(window, {...})` exports in each `.jsx` file with proper ES module exports:
   ```jsx
   export { LandingPage };
   ```
   And replace global references like `<LandingPage />` inside other files with imports:
   ```jsx
   import { LandingPage } from './landing.jsx';
   ```
4. Remove the three `<script src="https://unpkg.com/...">` tags for React and Babel — Vite bundles React from `node_modules`.
5. Run `npm run dev` and Replit will host it on port 5173 by default.

### Adding a backend (when you're ready)

Each surface has obvious API touchpoints. Suggested endpoints:

| Surface     | Endpoints                                                                 |
| ----------- | ------------------------------------------------------------------------- |
| Landing     | `GET /api/queue/summary` — aggregate per-branch queue counts              |
| Live Queue  | `GET /api/queue/:branchId` (poll every 5s, or upgrade to WebSocket)       |
| Dashboard   | `GET /api/me`, `GET /api/me/washes`, `GET /api/me/vehicles`               |
| POS         | `POST /api/tickets`, `POST /api/payments`, `GET /api/packages`            |
| CRM         | `GET /api/admin/customers`, `GET /api/admin/subscriptions`, etc.          |

Recommended stack for Replit:
- **Backend**: Node + Express (or Fastify) — easiest in Replit
- **DB**: Replit Database for prototyping, Postgres (Neon) for production
- **Auth**: Replit Auth, or Clerk/Auth.js for role-based (customer / lane staff / admin)
- **Realtime**: Server-Sent Events for the live queue (simpler than WebSockets, plays nice with Replit's HTTP-only deploy)

---

## 🧪 Tweaks panel

Toggle **Tweaks** in the floating bottom-right panel (or hide via the close button) to:

- Switch accent color
- Change density
- Toggle the "just washed" ticker
- Toggle chrome style

The panel is in `tweaks-panel.jsx` and persists via `postMessage` — for a real backend you can swap that for `localStorage` or user-preferences API.

---

## 🐞 Known prototype-only behaviors

- **All data is hardcoded** in each `.jsx` file (mock arrays of branches, customers, queue items). Replace with API calls.
- **Surface switcher** is shown for demo purposes — in production each surface lives at its own route (`/`, `/queue`, `/account`, `/pos`, `/admin`).
- **No auth gates** — POS and CRM should require authenticated lane-staff / admin roles.
- **Babel-in-browser is slow on cold load** — fine for design review, NOT for production. Migrate to Vite (above).

---

## 📝 License & ownership

Design and code prototype belong to Cuci Xpress. Brand colors, copy, and logos are property of Cuci Xpress.

Built as a design prototype — review before shipping to production.
